%GOHOME positions command prompt at top level directory

%   IFISS scriptfile: DJS; 9 January 2019.
% Copyright (c) 2005 D.J. Silvester, H.C. Elman, A. Ramage 

%cd('C:\Users\georg\Desktop\stochastic FEM\stoch_diffusion_multilevel')
% cd('C:\Users\mbbxwgp2\Desktop\stochastic FEM\stoch_diffusion_multilevel')
cd('/Users/user/Documents/MATLAB/stoch_diffusion_multilevel')

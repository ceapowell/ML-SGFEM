function f = stoch_specific_rhs3D(x,y,z,nel,norv)
%STOCH_SPECIFIC_RHS3D   deterministic nonconstant RHS 3D forcing function 
%   f = stoch_specific_rhs(x,y,nel,norv)
%   input
%          x          x coordinate vector
%          y          y coordinate vector
%          z          z coordinate vector
%          nel        number of elements
%          norv       number of random variables
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022  A. J. Crowder, G. Papanikos, C.E. Powell

  f0 = (3*ones(nel,1) - x.^2 - y.^2 - z.^2)/8.0e0;
  f=[f0,zeros(nel,norv)];

return
% ML_adapt_SGFEM set up stochastic diffusion reference problems (windows users)
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell
close all; clc; clear;
dim = default('<strong>Choose dimension of spatial domain: 2/3 (2D/3D)</strong> (default: 2D)\',2);
if dim == 2
    fprintf('\nSpecification of reference stochastic diffusion problem.')
    fprintf('\nChoose specific example');
    fprintf('\n     1  Square domain [-1,1] x [-1,1],      analytic KL expansion, non-constant source');
    fprintf('\n     2  Square domain [ 0,1] x [ 0,1],      Eigel synthetic random coefficient,  constant source')
    fprintf('\n     3  Square domain [ 0,1] x [ 0,1],      Powell synthetic random coefficient, constant source')
    fprintf('\n     4  L-shaped domain,                    Eigel synthetic random coefficient,  constant source\n')
    sn = default('',1);
    gohome
    if sn==1
        system('copy .\test_problems_setup\stoch_coeff_ex2_m.m .\stoch_specific_coeff_m.m');
        system('copy .\test_problems_setup\stoch_rhs_ex2.m .\stoch_specific_rhs.m');
        rd_type = 1;
        stoch_adapt_ML_SGFEM_diff
    elseif sn==2
        system('copy .\test_problems_setup\stoch_coeff_ex5_m.m .\stoch_specific_coeff_m.m');
        system('copy .\test_problems_setup\stoch_unit_rhs.m .\stoch_specific_rhs.m');
        rd_type = 2;
        stoch_adapt_ML_SGFEM_diff
    elseif sn ==3
        system('copy .\test_problems_setup\stoch_coeff_ex6_m.m .\stoch_specific_coeff_m.m');
        system('copy .\test_problems_setup\stoch_unit_rhs.m .\stoch_specific_rhs.m');
        rd_type = 3;
        stoch_adapt_ML_SGFEM_diff
    elseif sn ==4
        system('copy .\test_problems_setup\stoch_coeff_ex5_m.m .\stoch_specific_coeff_m.m');
        system('copy .\test_problems_setup\stoch_unit_rhs.m .\stoch_specific_rhs.m');
        rd_type = 4;
        stoch_adapt_ML_SGFEM_diff
    else
        error('reference problem datafile not found!')
    end
    
elseif dim == 3
    fprintf('\n<strong>Warning this code might be slow - requires a lot of memory</strong>\n')
    fprintf('\n<strong>Choose stochastic diffusion test problem</strong>')
    fprintf('\nChoose specific example');
    fprintf('\n     1  Cube domain [-1,1] x [-1,1] x [-1,1],      Analytic KL expansion, non-constant source');
    fprintf('\n     2  Cube domain [ 0,1] x [ 0,1] x [ 0,1],      Eigel synthetic random coefficient,  constant source\n')
    sn = default('',1);
    gohome
    if sn==1
        system('copy .\test_problems_setup\stoch_coeff3D_ex2_m.m .\stoch_specific_coeff3D_m.m');
        system('copy .\test_problems_setup\stoch_rhs_ex2_3D.m .\stoch_specific_rhs3D.m');
        rd_type = 1;
        stoch_adapt_ML_SGFEM_diff3D
    elseif sn==2
        system('copy .\test_problems_setup\stoch_coeff3D_ex5_m.m .\stoch_specific_coeff3D_m.m');
        system('copy .\test_problems_setup\stoch_unit_rhs3D.m .\stoch_specific_rhs3D.m');
        rd_type = 2;
        stoch_adapt_ML_SGFEM_diff3D
    else
        error('reference problem datafile not found!')
    end
else
    error('Wrong dimension input!')
end
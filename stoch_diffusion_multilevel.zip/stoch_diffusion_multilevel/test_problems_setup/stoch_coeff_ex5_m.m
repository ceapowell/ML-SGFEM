function a = stoch_specific_coeff_m(x,y,nel,norv,KL_DATA,n)
%STOCH_SPECIFIC_COEFF_M   synthetic stochastic diffusion coefficient
%   a = stoch_specific_coeff_m(x,y,nel,norv,KL_DATA,n)
%   input
%          x       :  x coordinate vector
%          y       :  y coordinate vector
%          nel     :  number of elements
%          norv    :  number of random variables
%          KL_DATA :  data related to KL-expansion
%   output
%          a       : synthetic stochastic diffusion coefficient
% This expansion is discussed in
% M. Eigel, C.J. Gittelson, C. Schwab, E. Zander
% Adaptive stochastic FEM,
% Comput. Methods Appl. Mech. Engrg. 270:247-269, 2014.
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022  A. J. Crowder, G. Papanikos, C.E. Powell
% Modified SIFISS function stoch_specific_coeff

% set decay rate of stochastic coefficients
sdecay = KL_DATA.decay;
if sdecay 
    sigma=2; alpha=0.547;
else 
    sigma=4; alpha=0.832;
end

a = zeros(nel,1);

if n == 0
    a(:) = ones(nel,1);
else
    kn = floor(-0.5e0+sqrt(0.25e0+2*n));
    beta_x = n-kn*(kn+1)/2; beta_y=kn-beta_x;
    a(:) = ( alpha(1)/ n^sigma(1) ) * cos( (2*pi*beta_x(1))*x(:) ) .* cos( (2*pi*beta_y(1))*y(:) );
end


return


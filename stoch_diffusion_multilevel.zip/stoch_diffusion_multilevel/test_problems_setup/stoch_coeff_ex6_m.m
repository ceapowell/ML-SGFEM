function a = stoch_specific_coeff_m(x,y,nel,norv,KL_DATA,n)
%STOCH_SPECIFIC_COEFF_M   synthetic stochastic diffusion coefficient
%   a = stoch_specific_coeff_m(x,y,nel,norv,KL_DATA,n)
%   input
%          x       :  x coordinate vector
%          y       :  y coordinate vector
%          nel     :  number of elements
%          norv    :  number of random variables
%          KL_DATA :  data related to KL-expansion
%          n       :  parameter number
%   output
%          a       : synthetic stochastic diffusion coefficient
%
% This expansion is discussed on p.393
% G. Lord, C.E. Powell, T. Shardlow,
% An Introduction to Computational Stochastic PDEs,
% Cambridge University Press, 2014.
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022  A. J. Crowder, G. Papanikos, C.E. Powell
%
%  Modified SIFISS function stoch_specific_coeff
%  authors D.J. Silvester, H.C. Elman, A. Ramage

% set length scale parameter
ell = KL_DATA.ell;

% one dimensional functions
ind=[0:norv-1];
nu1=[0.5.*exp(-pi*ind.^2.*ell^2)]'; nu2=nu1;
% compute all possible product pairs of 1D eigs
nu_prod=nu1*nu2';

% find 1D indices and compute the largest 2D eigs
for m=1:norv
    [maxcol,indrow]=max(nu_prod);
    [eigmax,jj]=max(maxcol);
    ii=indrow(jj);
    nu2D(m)=eigmax;
    nu2Dpos(m,:)=[ii,jj];
    nu_prod(ii,jj)=0;
end
format shorte

a = zeros(nel,1);
mu = KL_DATA.mu;
if n == 0
    a(:)=mu*ones(nel,1);
else
    k1=nu2Dpos(n,1); k2=nu2Dpos(n,2); sqeig=sqrt(nu2D(n));
    % 1d eig indices run from 0 to norv-1
    if (k1==1)&(k2==1)
        a(:)=sqeig*ones;
    elseif (k1==1)&(k2~=1)
        a(:)=sqrt(2)*sqeig *cos((k2-1).*pi.*y);
    elseif (k1~=1)&(k2==1)
        a(:)=sqrt(2)*sqeig *cos((k1-1).*pi.*x);
    else
        a(:)=2*sqeig *cos((k1-1).*pi.*x).*cos((k2-1).*pi.*y);
    end
end
return
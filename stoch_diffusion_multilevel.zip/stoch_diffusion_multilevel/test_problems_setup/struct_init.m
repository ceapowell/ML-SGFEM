% In this script we initialise all fields that are to be stored in the following
% structures. Some arent necessary. Some fields are allocated in a function
% before they are called, and don't techically need initialising. This
% approach is for completeness so that the dimension of the structures is
% fixed.
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell

% load smoother_matrices
% load interpolation_operators
% load A_matrices

% SGFEM approximation data
SGFEM_data.K      = cell(nc_max,nc_max,max_norv+1); % LHS FEM matrices
SGFEM_data.G_data = [];                             % Data for G matrices
SGFEM_data.F      = cell(1,nc_max);                 % Nonzero RHS contribution (associated with mu = 0)
SGFEM_data.DA     = cell(1,nc_max);                 % K0 Cholesky decomp.
SGFEM_data.U      = [];                             % Computied SGFEM modes


% Spatial error approximation data
s_data.A         = cell(1,nc_max);                  % LHS FEM matrices assocaited with B0
s_data.K         = cell(nc_max,nc_max,max_norv+1);  % RHS FEM matrices associated with B(uX,v)
s_data.F         = cell(1,nc_max);                  % Nonzero RHS contribution (associated with mu = 0)
s_data.DA        = cell(1,nc_max);                  % Cholesky decomp of A matrices
s_data.error_vec = [];                              % Vector of component spatial error estimates squared
s_data.error_est = [];                              % Total spatial estimate

% Parametric error approximation data
p_data.GPQ_data  = [];                              % Data for rectangular G matrices associated with RHS
p_data.Q_indset  = [];                              % Detail multi-indices
p_data.p_refine  = 1;                               % Alert algorithm to parametric refinement. Initialise as 1 to construct initial GPQ_data
p_data.ncq       = [];                              % Record position of NCQ in nc
p_data.error_vec = [];                              % Vector of component parametric error estimates squared
p_data.error_est = [];                              % Total parametric estimate

enrich_loc = []; indset_old = [];                   % used to initialise the resuse of G matrices
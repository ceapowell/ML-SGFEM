% user_inputs: ask the user to specify all required input parameters for the
% ML adaptive SGFEM algorithm
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell

% Set up the test problem
if rd_type == 1 && max_norv > 0 && dim == 2
    fprintf('\n<strong>Setting up KL expansion data</strong>\n')
    std_dev=default('--standard deviation? (default maximum standard deviation 0.15)',1.5e-01);
    if std_dev >0.15;  error('The standard deviation is larger than the maximum 0.15!');   end
    correl_x=default('--correlation length in x-direction? (default 2.0)',2.0e-00);
    correl_y=default('--correlation length in y-direction? (default 2.0)',2.0e-00);
    KL_DATA = stoch_kl_eigens(1,1,std_dev,correl_x,correl_y,max_norv);
    TP = 1;
    dom_type = 'square';
    
    
elseif rd_type == 2 && dim == 2
    fprintf('\n<strong>Setting up Eigel synthetic random coefficient expansion</strong>\n')
    KL_DATA.input = [1,1,0];
    sdecay=default('--slow/fast coefficient decay 1/0  (default slow)',1);
    if sdecay ~=0 && sdecay ~=1; error('Invalid input! The input value should be either 1 or 0.'); end
    KL_DATA.decay = sdecay;
    if sdecay
        TP = 2;
        dom_type = 'square';
    else
        TP = 3;
        dom_type = 'square';
    end
elseif rd_type== 3 && dim == 2
    fprintf('\n<strong>Setting up Powell synthetic random coefficient expansion</strong>\n')
    KL_DATA.input = [1,1,0];
    KL_DATA.mu = 2;
    ell=default('--correlation length coefficient (default is 0.8)',0.8);
    
    if ell< 0.8
        error('Invalid input. The correlation length should not be less than 0.8, otherwise discrete problems may not be well-posed.')
    end
    
    KL_DATA.ell = ell;
    TP = 4;
    dom_type = 'square';
elseif rd_type==4 && dim == 2
    fprintf('\n<strong>Setting up Eigel synthetic random coefficient expansion</strong>\n')
    KL_DATA.input = [1,1,0];
    sdecay=default('--slow/fast coefficient decay 1/0  (default slow)',1);
    if sdecay ~=0 && sdecay ~=1; error('Invalid input! The input value should be either 1 or 0.'); end
    KL_DATA.decay = sdecay;
    if sdecay == 0
        TP = 5;
    else
        TP = 6;
    end
    dom_type = 'Lshape';
elseif rd_type == 1 && max_norv > 0 &&  dim == 3
    fprintf('\n<strong>Setting up KL expansion data</strong>\n')
    std_dev=default('--standard deviation? (default 0.1)',1e-1);
    if std_dev >0.1  error('The standard deviation is larger than the maximum 0.1!');   end
    correl_x=default('--correlation length in x-direction? (default 4.0)',4.0e-00);
    correl_y=default('--correlation length in y-direction? (default 4.0)',4.0e-00);
    correl_z=default('--correlation length in z-direction? (default 4.0)',4.0e-00);
    KL_DATA = stoch_kl_eigens3D(1,1,1,std_dev,correl_x,correl_y,correl_z,max_norv);
    TP = 1;
    dom_type = 'cube';
    
elseif rd_type == 2 && dim == 3
    fprintf('\n<strong>Setting up 3D Eigel synthetic random coefficient expansion</strong>\n')
    KL_DATA.input = [1,1,0];
    sdecay=default('--slow/fast coefficient decay 1/0  (default slow)',1);
    if sdecay ~=0 && sdecay ~=1; error('Invalid input! The input value should be either 1 or 0.'); end
    KL_DATA.decay = sdecay;
    if sdecay
        TP = 2;
        dom_type = 'cube';
    else
        TP = 3;
        dom_type = 'cube';
    end
    KL_DATA.deg =10;
end

% Define initial SGFEM approximation
fprintf('\n<strong>Specify initial SGFEM approximation space</strong>\n')
noarv=default('--No. of parameters to activate at first step (default is 1)',1);

if noarv > max_norv, error('Oops.. need to increase parameter max_norv!'), end
if noarv>0,
    polyd=default('--Total polynomial degree for parametric approximation at first step (default is 1)',1);
    [indset] = stoch_indset(polyd,noarv);
    indset = [indset,zeros(length(indset),max_norv-noarv)];
    
else
    % set up the default index set
    def_indset=[0];
    indset=default('Input index set of polynomial degrees? (accept default)',def_indset);
    noarv=length(indset(1,:));
    indset = [indset,zeros(length(indset(:,1)),max_norv-noarv)];
end


if dim == 2
    qmethod=default('--Choose Q1(h)/Q2(h) spatial approximation 1/2? (default Q1)',1); % approximation specification
    if qmethod ~= 1 && qmethod ~=2; error('Invalid spatial approximation input! The input should be either 1 or 2.'); end
    nc=default('--Coarse grid parameter: 3 for underlying 8x8 grid (default is 16x16)',4);
    
    if nc<1, error('illegal parameter choice, try again.'), end
    if nc<2, error('very small grid parameter! the grid parameter should be bigger or equal to 2'), end
    
    
    if qmethod == 1
        if isequal(dom_type,'square')
            tol=default('\n<strong>Desired energy error tolerance</strong> (1.5e-3)',1.5e-3);
        else
            tol=default('\n<strong>Desired energy error tolerance</strong> (6.0e-3)',6.0e-3);
        end
        fprintf('\n<strong>Specify approximation space for error estimator</strong>\n')
        error_space =default('--Spatial error approximation space Q2(h)/Q1(h/2), 1/2? (default Q2(h))',1);
        if  error_space ~= 1 &&  error_space ~=2; error('Invalid input for the Spatial error approximation space! The input value should be either 1 or 2.'); end
    elseif qmethod == 2
        if isequal(dom_type,'square')
            if TP == 1
                tol=default('\n<strong>Desired energy error tolerance</strong> (1.1e-3)',1.1e-3);
            else
                tol=default('\n<strong>Desired energy error tolerance</strong> (1.5e-4)',1.5e-4);
            end
        else
            tol=default('<strong>Desired energy error tolerance</strong> (6.0e-3)',6.0e-3);
        end
        error_space =default('Spatial error approximation space Q4(h)/Q2(h/2), 1/2? (default Q4(h))',1);
        if  error_space ~= 1 &&  error_space ~=2; error('Invalid input for the Spatial error approximation space! The input value should be either 1 or 2.'); end
    end
else
    qmethod = 1; %  Q1 approximation in 3D
    tol=default('\n<strong>Desired energy error tolerance</strong> (8.0e-3)',8.0e-3);
    fprintf('\n<strong>Specify approximation space for error estimator</strong>\n')
    error_space =default('--Spatial error approximation space full Q2(h)/ reduced Q2(h), 1/2? (default reduced Q2(h))',2);
    if  error_space ~= 1 &&  error_space ~=2; error('Invalid input for the Spatial error approximation space! The input value should be either 1 or 2.'); end
    nc=default('--Coarse grid parameter: 3 for underlying 8x8x8 grid (default is 16x16x16)',4);
    if nc<1, error('illegal parameter choice, try again.'), end
    if nc<2, error('very small grid parameter! the grid parameter should be bigger or equal to 2'), end
end
if TP == 1 && qmethod == 1
    ad_rv = default('--Max no. extra parameters to activate in parametric space for error estimator (default is 5)',5);
elseif TP == 1 && dim == 2 && qmethod == 2
    ad_rv = default('--Max no. extra parameters to activate in parametric space for error estimator (default is 10)',10);
elseif TP == 2 || TP == 6
    ad_rv = default('--Max no. extra parameters to activate in parametric space for error estimator (default is 5)',5);
elseif TP == 3 || TP == 4 || TP==5
    ad_rv = default('--Max no. extra parameters to activate in parametric space for error estimator (default is 2)',2);
end
if  ad_rv<0  error('Invalid input! The input for the number of extra parameters should be positive.'); end

version = default('\n<strong>Choose the adaptive strategy</strong> 1/2  (default version 1)',1);                               % adaptive strategy versions 1 or 2.
if  version ~= 1 &&  version ~=2; error('Invalid input for the adaptive version! The input value should be either 1 or 2.'); end

fprintf('\n<strong>Printing, plotting and saving</strong>\n')
iter_out = default('--Display diagnostics on screen at each adaptive step? yes/no (1/0) (default yes) ',1);                    % set this to 1 to for onscreen details about each step of the algorithm
if  iter_out ~= 1 &&  iter_out ~=0; error('Invalid input! The input value should be either 1 or 0.'); end
plot_aprox_err = default('--Plot estimated errors and convergence rates? yes/no (1/0) (default yes) ',1);                      % set thid to 1 for plotting estimated errors and convergence rates
if  plot_aprox_err ~= 1 &&  plot_aprox_err ~=0; error('Invalid input! The input value should be either 1 or 0.'); end
if dim == 2
    if (TP ==1 && std_dev == 0.15 && correl_x == 2.0 && correl_y == 2.0) || (TP == 4 && ell == 0.8) || TP == 2 || TP ==3 || TP == 5 || TP == 6
       
        if TP ==1 && tol < 1.1e-3 && qmethod == 2
            eff_plot = 0;
        elseif (TP == 2 || TP == 3) && tol < 1.5e-4 && qmethod == 2
            eff_plot = 0;
        elseif TP == 4 && tol < 1.5e-4 && qmethod == 2
            eff_plot = 0;
        elseif (TP == 5 || TP == 6) && tol < 6e-3 && qmethod == 2
            eff_plot = 0;
        else
            eff_plot = default('--Compute reference errors and plot effectivity indices? yes/no (1/0) (default yes) ',1);          % set this to 1 to compute reference errors and plot effectivity indices
        end
        
        if  eff_plot ~= 1 &&  eff_plot ~=0; error('Invalid input! The input value should be either 1 or 0.'); end
        
    else
        eff_plot = 0;
    end
else
    eff_plot = 0;
end
plot_mean_var =  default('--Plot mean/variance of final approximation? yes/no (1/0) (default yes) ',1);
if  plot_mean_var ~= 1 &&  plot_mean_var ~=0; error('Invalid input! The input value should be either 1 or 0.'); end

plot_stat_param = default('--Display info about evolution of parametric space? yes/no (1/0) (default yes) ',1);
if  plot_stat_param ~= 1 &&  plot_stat_param~=0; error('Invalid input! The input value should be either 1 or 0.'); end

save_final_res = default('--Save ML-SGFEM results? yes/no (1/0) (default yes) ',1);
if  save_final_res ~= 1 &&  save_final_res ~=0; error('Invalid input! The input value should be either 1 or 0.'); end

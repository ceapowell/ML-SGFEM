function a = stoch_specific_coeff3D_m(x,y,z,nel,norv,KL_DATA,n)
%STOCH_SPECIFIC_COEFF3D_M  synthetic stochastic diffusion coefficient
%   a = stoch_specific_coeff3D_m(x,y,z,nel,norv,KL_DATA,n)
%   input
%          x       :  x coordinate vector
%          y       :  y coordinate vector
%          nel     :  number of elements
%          norv    :  number of random variables
%          KL_DATA :  data related to KL-expansion
%          n       :  parameter number
%   output
%          a       : synthetic stochastic 3D diffusion coefficient
%
% This expansion is  a 3D extension of the 2D expansion discussed in
% M. Eigel, C.J. Gittelson, C. Schwab, E. Zander Adaptive stochastic FEM,
% Comput. Methods Appl. Mech. Engrg. 270:247-269, 2014.
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022  A. J. Crowder, G. Papanikos, C.E. Powell

% initialisation
a=zeros(nel,1);

% generate betas
betas = double(stoch_indset(KL_DATA.deg,3));

% set decay rate of stochastic coefficients
sdecay = KL_DATA.decay;

if sdecay
    sigma=2; alpha=0.547;
else
    sigma=4; alpha=0.832;
end
if n == 0
    a(:,1)=ones(nel,1);
else
    % set a_m
    beta_x = betas(n+1,1);  beta_y = betas(n+1,2); beta_z = betas(n+1,3);
    a(:) = alpha / (n^(sigma)) * cos(2*pi*beta_x*x) .* cos(2*pi*beta_y*y).* cos(2*pi*beta_z*z);
end

return
function f = stoch_specific_rhs3D(x,y,z,nel,norv)
%STOCH_SPECIFIC_RHS3D   unit deterministic RHS forcing function
%   f = stoch_specific_rhs(x,y,z,nel)
%   input
%          x          x coordinate vector
%          y          y coordinate vector
%          z          y coordinate vector
%          nel        number of elements
%          norv       number of random variables
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022  A. J. Crowder, G. Papanikos, C.E. Powell
%
f=[ones(nel,1),zeros(nel,norv)];
return

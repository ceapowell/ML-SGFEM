function f = stoch_specific_rhs(x,y,nel,norv)
%STOCH_SPECIFIC_RHS   unit deterministic RHS forcing function
%   f = stoch_specific_rhs(x,y,nel)
%   input
%          x          x coordinate vector
%          y          y coordinate vector
%          nel        number of elements
%          norv       number of random variables
%
% SIFISS function: DJS; 2 May 2013.
% Copyright (c) 2013 A. Bespalov, C.E. Powell, D.J. Silvester
%
f=[ones(nel,1),zeros(nel,norv)];
return

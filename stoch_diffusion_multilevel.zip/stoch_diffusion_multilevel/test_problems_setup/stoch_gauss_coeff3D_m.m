function aa = stoch_gauss_coeff3D_m(s,t,l,xl,yl,zl,norv,KL_DATA,n)
%STOCH_GAUSS_COEFF3D_M evaluates stochastic coefficient at Gauss point
%   aa = stoch_gauss_coeff3D_m(s,t,xl,yl,norv,KL_DATA,n);
%   input
%          s       :  reference element x coordinate
%          t       :  reference element y coordinate
%          l       :  reference element z coordinate
%          xl      :  physical element x vertex coordinates
%          yl      :  physical element y vertex coordinates
%          zl      :  physical element z vertex coordinates
%          norv    :  number of random variables
%          KL_DATA :  data related to KL-expansion
%          n       :  parameter number
%   output
%          aa      : stochastic 3D coefficient
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022  A. J. Crowder, G. Papanikos, C.E. Powell

nel=length(xl(:,1));
zero_v = zeros(nel,1); xx=zero_v; yy=xx; zz=xx;
[phi_e,~,~,~] = shape3D(s,t,l);
for ivtx=1:8
    xx = xx + phi_e(ivtx) * xl(:,ivtx);
    yy = yy + phi_e(ivtx) * yl(:,ivtx);
    zz = zz + phi_e(ivtx) * zl(:,ivtx);
end
aa=stoch_specific_coeff3D_m(xx,yy,zz,nel,norv,KL_DATA,n);
return
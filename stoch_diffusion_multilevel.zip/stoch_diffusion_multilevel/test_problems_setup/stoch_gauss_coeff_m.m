function aa = stoch_gauss_coeff_m(s,t,xl,yl,norv,KL_DATA,n)
%STOCH_GAUSS_COEFF_M evaluates stochastic coefficient at Gauss point
%   aa = stoch_gauss_coeff(s,t,xl,yl,norv,KL_DATA,n);
%   input
%          s       :  reference element x coordinate   
%          t       :  reference element y coordinate
%          xl      :  physical element x vertex coordinates 
%          yl      :  physical element y vertex coordinates  
%          norv    :  number of random variables
%          KL_DATA :  data related to KL-expansion
%          n       :  parameter number
%   output
%          aa      : stochastic coefficient
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022  A. J. Crowder, G. Papanikos, C.E. Powell
% 
% Modified SIFISS function stoch_gauss_coeff
% authors A. Bespalov, C.E. Powell, D.J. Silvester

  nel=length(xl(:,1));
  zero_v = zeros(nel,1); xx=zero_v; yy=xx;
  [phi_e,dphids,dphidt] = shape(s,t);
  for ivtx=1:4 
      xx = xx + phi_e(ivtx) * xl(:,ivtx);
      yy = yy + phi_e(ivtx) * yl(:,ivtx);
  end
  aa=stoch_specific_coeff_m(xx,yy,nel,norv,KL_DATA,n);
return


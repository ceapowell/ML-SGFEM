% STOCH_adapt_ML_SGFEM_diff solves stochastic diffusion problem using adaptive multilevel
% stochastic Galerking method using quadrilateral elements in square and L-shape domains.
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell


global TP iter_out eff_plot matrix_count dom_type qmethod error_space


max_norv = 500;            % limit the number of random variables

user_inputs            % User inputs
matrix_count = 0;
total_est = inf;
[P,~] = size(indset);  % detemine quantity of multi-indices
nc_max = 20;           % set the maximum size of the spatial grid
nc = nc*ones(1,P);
iteration_number = 1;
if length(nc) ~= P; error('Incorrect number of levels defined'); end

fprintf('\n')
disp('Constructing SGFEM approximation ...')
disp('===================================================')

struct_init; % initialize data structures

a_time = tic;
sgfem_time = 0;
error_time = 0;
MM  = noarv;
while total_est > tol
    
    if iter_out == 1
        fprintf('Iteration  = %d.\n',iteration_number)
        disp('===================================================')
        fprintf('\n'),
        [Grid_levels,~,Nt] = unique(nc);
        Grid_levels =Grid_levels';
        for i = 1:size(Grid_levels,1)
            No_of_terms(i,1)  = nnz(Nt==i);
        end
        T = table(Grid_levels,No_of_terms,'RowNames',{});
        format short
        disp(T)
        disp('--------------------------------------------')
        fprintf('No of activated variables = %d.\n',MM)
        clear No_of_terms
    end
    % ------------------- find the multilevel SGFEM solution ------------------------------------
    sgfem_time_iter = tic;
    SGFEM_data = adaptive_multilevel_SGFEM(noarv,nc,indset,indset_old,SGFEM_data,KL_DATA);
    %-------------------------------------------------------------------------------------------
    sgfem_time = sgfem_time + toc(sgfem_time_iter);
    sgfem_time_stores(iteration_number) = sgfem_time;
    error_time_iter = tic;
    % ---- A posteriori error estimation using global residual method --------------------------
    ML_adapt_diffpost
    % ------------------------------------------------------------------------------------------
    error_time = error_time + toc(error_time_iter);
    error_time_stores(iteration_number) = error_time;
    total_est = sqrt( s_data.error_est^2 + p_data.error_est^2 );
    time_stores(iteration_number) = toc(a_time);
    
    if iter_out == 1
        fprintf('\n           Cumulative time = %.2f seconds.',toc(a_time))
        fprintf('\nTotal energy error estimate = %5.4e.'       ,total_est)
        if eff_plot == 1
            fprintf('\n          Effectivity index = %3.2f.\n',total_est/SGFEM_data.ref_error);
        end
        fprintf('\n')
        disp('===================================================')
    end
    
    % save parameters of current SGFEM approx
    nc_old = nc;
    indset_old = indset;
    noarv_old = noarv;
    MM_old = MM;
    iter(iteration_number) = iteration_number;
    for i =1:noarv_old active(1,i) = sum(indset(:,i)); end
    Non_active = find(active == 0);
    if isempty(Non_active) 
        MM = noarv;
    else
        MM = noarv - length(Non_active);
    end
    noarv_iter(1,iteration_number) = MM;
    noarv_iter(2,iteration_number) = size(indset,1);
    
    if isequal(dom_type,'square')
        Ndof_old = (2.^nc_old-1).^2; % number of internal (solution) nodes per level
    else
        Ndof_old = (2.^nc_old-1).^2 -2.^(2.*nc_old-2);
    end
    
    
    [enrich_loc,enrich_type] = enrichment_indices(version,nc,p_data.ncq,s_data.error_vec,p_data.error_vec,Ndof_old);
    
    if enrich_type == 1
        p_data.p_refine = 0;
        nc(enrich_loc) = nc(enrich_loc) + 1;
    else
        p_data.p_refine = 1;
        new_ind = p_data.Q_indset(enrich_loc,:);
        indset = [indset; new_ind];
        
        nc = [nc nc(p_data.ncq)*ones(1,length(enrich_loc))]; % update indset and nc
        [~,nz,~] = find(indset); noarv = max(nz);            % determine new M
    end
    
    DOFs_iter(iteration_number) = sum(Ndof_old);
    ERRs_iter(iteration_number) = total_est;
    s_er_iter(iteration_number) = s_data.error_est;
    p_er_iter(iteration_number) = p_data.error_est;
    
    if eff_plot == 1;
        ERRs_ref_iter(iteration_number) = SGFEM_data.ref_error;
        EFFs_iter(iteration_number) = total_est/SGFEM_data.ref_error;
    end
    
    iteration_number = iteration_number + 1;

end

Total_DOF = sum(Ndof_old);

disp('-------------- Convergence achieved! --------------')
disp('===================================================')

toc(a_time)

if eff_plot == 1; fprintf('Reference error = %5.4e.\n',SGFEM_data.ref_error); end

fprintf('Estimated error = %5.4e.',total_est)
fprintf('\nTotal iterations = %i.',iteration_number-1)
fprintf('\nTotal #DOF       = %i.\n\n',Total_DOF)
format short

clear No_of_terms
[final_Grid_levels,~,Ntf] = unique(nc_old);
final_Grid_levels =final_Grid_levels';
for i = 1:size(final_Grid_levels,1)
    No_of_terms(i,1)  = nnz(Ntf==i);
end
T = table(final_Grid_levels,No_of_terms,'RowNames',{});
disp(T)
fprintf('Total no. of activated variables = %d.\n',MM_old)
if plot_mean_var
    U_interp = multi_stats(SGFEM_data.U,size(indset_old,1),nc_old,indset_old,noarv_old); % plot expectation and variance
end
% ---------------- Plot errors  and effectivity indices -------------------------------------------------------
convergence_plots
%------------------Bar plot with the dimension of parametric approximation space
% -----------------and  the number of activated parameters at each step--------
if plot_stat_param
    figure
    bar(iter,noarv_iter')
    legend({'No of activated parameters','No of parametric basis polynomials'},'FontSize',12);
    xlabel('Algorithm step');
end
%---------------- Save results --------------------------------------------
if save_final_res
    cd datafiles
    field = 'DA';
    SGFEM_data = rmfield(SGFEM_data,field);
    s_data = rmfield(s_data,field);
    name = 'ML_adapt_results';
    save([name,'.mat'],'-v7.3')
end

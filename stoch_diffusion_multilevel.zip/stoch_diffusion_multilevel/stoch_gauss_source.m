function ff = stoch_gauss_source(s,t,xl,yl,norv)
%STOCH_GAUSS_SOURCE evaluates stochastic source term at Gauss point 
%   ff = stoch_gauss_source(s,t,xl,yl);
%   input
%          s         reference element x coordinate   
%          t         reference element y coordinate
%          xl        physical element x vertex coordinates 
%          yl        physical element y vertex coordinates  
%          norv      number of random variables
%
%   calls function: stoch_specific_rhs
%   SIFISS function: DJS; 17 March 2013.
% Copyright (c) 2013 A. Bespalov, C.E. Powell, D.J. Silvester
  nel=length(xl(:,1));
  zero_v = zeros(nel,1); xx=zero_v; yy=xx;
  [phi_e,dphids,dphidt] = shape(s,t);
  for ivtx=1:4 
      xx = xx + phi_e(ivtx) * xl(:,ivtx);
      yy = yy + phi_e(ivtx) * yl(:,ivtx);
  end
  ff=stoch_specific_rhs(xx,yy,nel,norv);
  return


function [GPQ_data,Q_indset] = adapt_stoch_gmatrices_error(GPQ_data_old,P_indset,P_indset_old,Q_indset_old,noarvx,norv,enrich_loc,additional_RV)
% ADAPT_STOCH_GMATRICES_ERROR augment the G matrices with new random  variables for the error estimation
%[GPQ_data,Q_indset] = adapt_stoch_gmatrices_error(GPQ_data_old,P_indset,P_indset_old,Q_indset_old,noarvx,norv,enrich_loc,additional_RV)
% input
%      GPQ_data_old  : Old G matrices
%      P_indset      : set of multi-indices
%      P_indset_old  : old  P set of multi-indices 
%      Q_indset_old  : old  Q set of multi-indices
%      noarvx        : number of active random variables
%      norv          : number of random variables 
%      enrich_loc    : Indices locations with the highest error 
%      additional_RV : number of additional random variables
%
%
% outpt
%      GPQ_data      : new G matrices  
%      Q_indset      : new set Q of multi-indices  
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell

P_old = size(P_indset_old,1);
Q_old = size(Q_indset_old,1);

P = size(P_indset,1);

[~,nz,~] = find(Q_indset_old); noarvx_old = max(nz);
[~,nz,~] = find(P_indset); noarv = max(nz);

if P_old == 0 % this is for iteration 1, i.e. the first parametric error estimation
    
    Q_indset = stoch_new_indset_multi(P_indset,noarv,norv,additional_RV);
    Q_indset = setdiff(Q_indset,P_indset,'rows');
    Q = size(Q_indset,1);
    
    I = eye(noarvx,'uint8');
    GPQ_data = cell(Q,noarvx);
    
    for m = 1:noarvx
        GPQ_data = find_stoch_entries(m,GPQ_data,noarvx,P,Q,0,0,P_indset,Q_indset,I);
    end
    
else
    
    P_indset_new = P_indset(P_old+1:end,:);
    P_new = size(P_indset_new,1);
    
    Q_indset_save =  Q_indset_old; % determine which indices in Q we have already saved data for
    Q_indset_save(enrich_loc,:) = [];
    
    [Q_indset_temp,QQ,JJ] = stoch_new_indset_multi(P_indset,noarv,norv,additional_RV);    
    JJ = reshape(JJ,P,noarvx); QQ = mat2cell(QQ,P*ones(noarvx,1),noarvx);
       
    [~,II] = setdiff(Q_indset_temp(:,1:noarvx),[P_indset(:,1:noarvx); Q_indset_save(:,1:noarvx)],'rows');
    Q_indset_new = Q_indset_temp(II,:); % This approach avoids sorting hundreds of 0's
    
    KK = cell(noarvx,1); QQ_new = cell(noarvx,1);
    for m = 1:noarvx
        [~,IA,KK{m}] = intersect(JJ(:,m),II);
        QQ_new{m} = QQ{m}(IA,:);
    end
    
    % We have achieved QQ_new{m} = Q_indset_new(KK{m},:), i.e. KK{m} contains
    % the locations of the canditate set QQ{m} in actual set Q_indset_new.
    % QQ{m} are the only potential neighbouring indices in the mth position
    % This dramatically speeds up the code. card(QQ{m}) is significantly
    % less than card(Q_indset_new).
    
    [~,I1,I2] = intersect(Q_indset_temp(:,1:noarvx),Q_indset_save(:,1:noarvx),'rows') ;    
    LL = cell(noarvx,1); QQ_save = cell(noarvx,1);
    
    for m = 1:noarvx
        [~,J1,J2] = intersect(I1,JJ(:,m));
        LL{m} = I2(J1);
        QQ_save{m} = QQ{m}(J2,:);
    end
    
    % A similar process to above. This achieves QQ_save{m} = Q_indset_save(LL{m},:)
    
    Q_new = size(Q_indset_new,1); Q_save = size(Q_indset_save,1);
    
    Q_indset = [Q_indset_save; Q_indset_new]; % constructing Q this way ensures the data stays in the correct order for the lists
    Q = size(Q_indset,1);
    
    GPQ_data = cell(Q,noarvx);
    
    for m=1:noarvx_old % retain data for indices that werent added to JP
        GPQ_data(1:Q_save,m) = GPQ_data_old(setdiff(1:Q_old,enrich_loc),m);
    end
    
    I = eye(noarvx,'uint8');
    
    for m = 1:noarvx
        
        % three function calls rather than three almost identical loops
        
        GPQ_data = efficient_find_stoch_entries(m,GPQ_data,noarvx,P_old,Q_save ,0    ,P_indset_old,QQ_new{m} ,I,KK{m}); % P_old with a refined Q_new
        GPQ_data = efficient_find_stoch_entries(m,GPQ_data,noarvx,P_new,0      ,P_old,P_indset_new,QQ_save{m},I,LL{m}); % P_new with a refined Q_save
        GPQ_data = efficient_find_stoch_entries(m,GPQ_data,noarvx,P_new,Q_save ,P_old,P_indset_new,QQ_new{m} ,I,KK{m}); % P_new with a refined Q_new
     
    end
    
end

end

function GPQ_data = efficient_find_stoch_entries(m,GPQ_data,noarvx,testing_count,n_diff,k_diff,test_indset1,test_indset2,I,KK)

if isempty(test_indset2) == 0
    for k = 1:testing_count
        
        nu = test_indset1(k,1:noarvx) + I(m,:);
        [s,n] = max(sum(test_indset2==nu,2)); 
        
        if s == noarvx
            GPQ_data{KK(n)+n_diff,m} = [GPQ_data{KK(n)+n_diff,m}; k+k_diff double(nu(m))/(sqrt(4.0e0*double(nu(m))^2-1.0e0))];
        end
        
    end
end

end

function GPQ_data = find_stoch_entries(m,GPQ_data,noarvx,testing1,testing2,n_diff,k_diff,test_indset1,test_indset2,I)
for k = 1:testing1
    
    nu = test_indset1(k,1:noarvx) + I(m,:);
    [s,n] = max(sum(test_indset2(:,1:noarvx)==nu,2)); % no longer need to use repmat
    
    if s == noarvx
        GPQ_data{n+n_diff,m} = [GPQ_data{n+n_diff,m}; k+k_diff double(nu(m))/(sqrt(4.0e0*double(nu(m))^2-1.0e0))];
    end
    
end
end














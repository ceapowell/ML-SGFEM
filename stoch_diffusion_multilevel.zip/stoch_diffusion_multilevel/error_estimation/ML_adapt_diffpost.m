% ML_adapt_diffpost main routine for spatial and parametric a posteriori error estimation using global residual
% methods
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell
if dim == 2
    if qmethod ==1
        if error_space == 1
            s_data = spatial_error_est(nc,indset,SGFEM_data.U,KL_DATA,SGFEM_data.G_data,s_data);
        else
            [s_data,SGFEM_data] = spatial_error_est_bilinears(nc,indset,SGFEM_data.U,KL_DATA,SGFEM_data.G_data,s_data,SGFEM_data);
        end
        [p_data,SGFEM_data.K] = parametric_error_est(nc,nc_max,ad_rv,max_norv,indset,SGFEM_data.U,KL_DATA,indset_old,enrich_loc,p_data,SGFEM_data.DA,SGFEM_data.K);
    else
        if error_space == 1
            s_data = q2_spatial_error_est(nc,indset,SGFEM_data.U,KL_DATA,SGFEM_data.G_data,s_data);
        else
            [s_data,SGFEM_data] = spatial_error_est_biquadratics(nc,indset,SGFEM_data.U,KL_DATA,SGFEM_data.G_data,s_data,SGFEM_data);
        end
        [p_data,SGFEM_data.K] = parametric_q2_error_est(nc,nc_max,ad_rv,max_norv,indset,SGFEM_data.U,KL_DATA,indset_old,enrich_loc,p_data,SGFEM_data.DA,SGFEM_data.K);
    end
else  % 3D case
    
    if error_space == 1
        s_data = fullq2_spatial_error_est3D(nc,indset,SGFEM_data.U,KL_DATA,SGFEM_data.G_data,s_data);
    else
        s_data = reducedq2_spatial_error_est3D(nc,indset,SGFEM_data.U,KL_DATA,SGFEM_data.G_data,s_data);
    end
    [p_data,SGFEM_data.K] = parametric_error_est3D(nc,nc_max,ad_rv,max_norv,indset,SGFEM_data.U,KL_DATA,indset_old,enrich_loc,p_data,SGFEM_data.DA,SGFEM_data.K);
    
end
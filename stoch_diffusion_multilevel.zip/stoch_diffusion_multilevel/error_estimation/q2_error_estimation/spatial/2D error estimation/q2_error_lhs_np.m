function [A,f] = q2_error_lhs_np(q,m,nc,norv,KL_DATA)
% Q2_ERROR_LHS_NP computes stiffness matrix of the bilinear form B0 
% and linear functional F of the  left and the right hand side 
% of the residual equation: 
%             B0(eY,v) = F(v) - B(ux,v)
% where ux is the Q2 ML SGFEM approximation and eY,v biquartic (Q4) bubble functions 
%[A,f] =  q2_error_lhs_np(q,m,nc,norv,KL_DATA)
% input 
%      q          : index of multi-indices
%      m          : index of parameter under consideration
%      nc         : FEM levels for each multi-index    
%      KL_DATA    : data related to KL-expansion
%
% outpt
%          A   : stiffness matrix
%          f   : rhs vector
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell


ncq = nc(q);
global dom_type;
[ev,mvv,xy,~] = grid_data(ncq);
nel = size(mvv,1);
nsubel = size(ev,1);
[mv,bound] = q2_error_connectivity_array(nsubel);
if isequal(dom_type,'square')
    nvtx = sqrt(nsubel)*(2*sqrt(nsubel) + 1) + sqrt(nsubel)*(sqrt(nsubel) + 1);  % number of q4 nodes in mesh excluding vertices
else
    nvtx = max(mv(:));  %2*sqrt(nel/3)*(4*sqrt(nel/3) ) + 2*sqrt(nel/3)*(4*sqrt(nel/3) ); % number of q4 nodes in mesh excluding vertices    
end
x = xy(:,1); y = xy(:,2); 
A = sparse(nvtx,nvtx);
f = zeros(nvtx,1);

ngpt = 10; [oneg,onew] = gausspoints_oned(ngpt); [s,t,wt] = gausspoints_twod(oneg,onew); % setup quadrature for stiffness matrices
nngpt = ngpt^2;

A_local = zeros(nel,16,16); % initialise local LHS
f_local = zeros(nel,16); % initialise local RHS
xl_v = x(mvv(:,1:4)); yl_v = y(mvv(:,1:4));

for igpt = 1:nngpt
    
    sigpt = s(igpt); tigpt = t(igpt); wght = wt(igpt);
    
    [jac,invjac,~,~,~] = deriv(sigpt,tigpt,xl_v,yl_v);
    [qphi,dqphidx,dqphidy] = qqderiv(sigpt,tigpt,xl_v,yl_v);
    
    coeff = stoch_gauss_coeff_m(sigpt,tigpt,xl_v,yl_v,norv,KL_DATA,m);
    rhs = stoch_gauss_source(sigpt,tigpt,xl_v,yl_v,0);

    % vectorised version
    f_local = f_local + wght*rhs(:).*qphi(:,10:25).*jac(:);
    A_local = A_local + wght*coeff(:).*( dqphidx(:,10:25).*permute(dqphidx(:,10:25),[1 3 2]) + dqphidy(:,10:25).*permute(dqphidy(:,10:25),[1,3,2]) ).*invjac(:);
end

% construct global matrix concatenating local ones

for krow = 1:16
    nrow = mv(:,krow);
    f(nrow,1) = f(nrow,1) + f_local(:,krow);
end

[Nrows,Ncols] = size(mv);
ncol = repmat(reshape(mv,Nrows*Ncols,1),16,1);

nrow = repmat(mv,Ncols,1);

A = sparse(nrow(:),ncol,A_local(:),nvtx,nvtx);
A(bound,:) = []; A(:,bound) = []; f(bound) = []; % apply zero dirichlet BCs and remove old nodes

end

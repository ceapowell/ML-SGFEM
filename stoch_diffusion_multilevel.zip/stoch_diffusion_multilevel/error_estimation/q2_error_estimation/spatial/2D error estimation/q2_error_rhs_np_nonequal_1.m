function [A] = q2_error_rhs_np_nonequal_1(q,r,m,nc,norv,KL_DATA)
% Q2_ERROR_RHS_NQ_NONEQUAL_1 computes stiffness matrix of the internal residual
% B(ux,v) for  non-equal grid levels (ux Q2 SGFEM solution defined in coarse mesh)
% v  biquartic (Q4) bubble functions
%[A] = q2_error_rhs_np_nonequal_1_new_version(q,r,m,nc,norv,KL_DATA)
% input
%
%      q,r        : index of multi-indices
%      m          : index of parameter under consideration
%      nc         : FEM levels for each multi-index
%      norv       : total number of parameters
%      KL_DATA    : data related to KL-expansion
%
% outpt
%          A      : stiffness matrix
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell


global dom_type;
ncq = nc(q); % solution level
ncr = nc(r); % error `detail' level

[ev_q,mv_q,xy_q,bound_sol] = grid_data(ncq);
[ev_r,mv_r,xy_r] = grid_data(ncr);

nsubel_q = length(ev_q(:,1)); % number of coarse elements
nsubel_r = length(ev_r(:,1)); % number of fine elements


nel_q = length(mv_q(:,1)); % number of coarse elements
nel_r = length(mv_r(:,1)); % number of fine elements


[mv,bound_detail] = q2_error_connectivity_array(nsubel_r);

nvtx_q = size(xy_q,1); % number of coarse and fine DOF

if isequal(dom_type,'square')
    nvtx_r = sqrt(nsubel_r)*(2*sqrt(nsubel_r) + 1) + sqrt(nsubel_r)*(sqrt(nsubel_r) + 1); % number of q4 nodes in mesh excluding vertices
else
    nvtx_r = max(mv(:));% number of q4 nodes in mesh excluding vertices
end

x_q  = xy_q(:,1);         y_q = xy_q(:,2); % coarse data
xl_q = x_q(mv_q(:,1:4)); yl_q = y_q(mv_q(:,1:4));

x_r  = xy_r(:,1);         y_r = xy_r(:,2); % fine data
xl_r = x_r(mv_r(:,1:4)); yl_r = y_r(mv_r(:,1:4));

lev_diff = abs(ncq-ncr);
n_subel = (2^lev_diff)^2; % determine how many fine elements per coarse element - minimum is four if levels are not equal

el_save = fine_el_retrieval(nel_q,nel_r); % this is the numbering of the fine elements which sit in each coarse element

ngpt = 7; [oneg,onew] = gausspoints_oned(ngpt); [s,t,wt] = gausspoints_twod(oneg,onew); nngpt=ngpt^2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% new approach
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

coarse_x_vec = repmat(xl_q,n_subel,1);
coarse_y_vec = repmat(yl_q,n_subel,1);

fine_x = xl_r(el_save,:);
fine_y = yl_r(el_save,:);

[ref_nodes_x, ref_nodes_y] = boundary_transform_squ_vec(coarse_x_vec,coarse_y_vec,fine_x,fine_y);

phi_st = vshape(s',t')';
s_trans = ref_nodes_x*phi_st; t_trans = ref_nodes_y*phi_st;

a_small = zeros(nel_r,16,9);

for igpt = 1:nngpt
    
    sigpt = s(igpt); tigpt = t(igpt); wght = wt(igpt);
    
    [invjac_c,~,dphidx_c,dphidy_c] = vqderiv(s_trans(:,igpt),t_trans(:,igpt),coarse_x_vec,coarse_y_vec);
    [~,dphidx_f,dphidy_f] = qqderiv(sigpt,tigpt,fine_x,fine_y);
    
    coeff = stoch_gauss_coeff_m(sigpt,tigpt,fine_x,fine_y,norv,KL_DATA,m);
    
    for j = 1:16
        for i = 1:9
            a_small(:,j,i) = a_small(:,j,i) + wght(1)*coeff(:).*(dphidx_c(:,i).*dphidx_f(:,j+9)+dphidy_c(:,i).*dphidy_f(:,j+9)).*invjac_c(:);
        end
    end
    
end

row_index = repmat(repmat(mv_q,n_subel,1),16,1);
col_index = repmat(mv(el_save,:),1,9);

A = sparse(row_index(:),col_index(:),a_small(:),nvtx_q,nvtx_r);

A(bound_sol,:) = [];
A(:,bound_detail) = [];

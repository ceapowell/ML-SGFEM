function [A] = q2_error_rhs_np_equal(q,m,nc,norv,KL_DATA)
% Q2_ERROR_RHS_NQ computes stiffness matrix of the internal residual B(ux,v) for
% grids at the same level with  biquartic (Q4) bubble functions
%[A] = q2_error_rhs_np_equal(q,m,nc,norv,KL_DATA)
% input
%
%      q          : index of multi-index
%      m          : index of parameter under consideration
%      nc         : FEM levels for each multi-index
%      norv       : total number of parameters
%      KL_DATA    : data related to KL-expansion
%
% outpt
%          A   : stiffness matrix
%
% Multilevel SGFEM function: GP; 03 November 2021.
% Copyright (c) 2020  G Papanikos, A.J. Crowder, C.E. Powell


% implementing Q4(h) error estimation
global dom_type;
ncq = nc(q);

[ev,mvv,xy,bound_sol] = grid_data(ncq);
nel = size(mvv,1);
nsubel = size(ev,1);

[mv,bound] = q2_error_connectivity_array(nsubel);


if isequal(dom_type,'square')
    nvtx = sqrt(nsubel)*(2*sqrt(nsubel) + 1) + sqrt(nsubel)*(sqrt(nsubel) + 1); % number of q4 nodes in mesh excluding vertices
else
    nvtx = max(mv(:));  %sqrt(nel/3)*(2*sqrt(nel/3) + 1) + sqrt(nel/3)*(sqrt(nel/3) + 1); % number of q4 nodes in mesh excluding vertices
end
nvtx_sol = size(xy,1);

x = xy(:,1); y = xy(:,2);
A = sparse(nvtx_sol,nvtx);

ngpt = 3; [oneg,onew] = gausspoints_oned(ngpt); [s,t,wt] = gausspoints_twod(oneg,onew); % setup quadrature for stiffness matrices
nngpt = ngpt^2;

A_local = zeros(nel,9,16); % initialise local LHS

xl_v = x(mvv(:,1:4)); yl_v = y(mvv(:,1:4));

for igpt = 1:nngpt
    
    sigpt = s(igpt); tigpt = t(igpt); wght = wt(igpt);
    
    [~,invjac,~,~,~]    = deriv(sigpt,tigpt,xl_v,yl_v);
    [~,dphidx2,dphidy2] = qderiv(sigpt,tigpt,xl_v,yl_v);
    [~,dphidx4,dphidy4] = qqderiv(sigpt,tigpt,xl_v,yl_v);
    
    coeff = stoch_gauss_coeff_m(sigpt,tigpt,xl_v,yl_v,norv,KL_DATA,m);
    
    A_local = A_local + wght*coeff(:).*( dphidx2.*permute(dphidx4(:,10:25),[1 3 2]) + dphidy2.*permute(dphidy4(:,10:25),[1,3,2]) ).*invjac(:);
    
    
end

[Nrows,Ncols] = size(mvv);
nrow = repmat(reshape(mvv,Nrows*Ncols,1),16,1);

ncol = repmat(mv,Ncols,1);

A = sparse(nrow,ncol(:),A_local(:),nvtx_sol,nvtx);

A(bound_sol,:) = []; A(:,bound) = []; % apply zero dirichlet BCs
function [A,f] = q1_3Dreducedq2_error_lhs_np(q,m,nc,norv,KL_DATA)
% Q1_3DREDUCEDQ2_ERROR_LHS_NP computes stiffness matrix of the bilinear form B0 
% and linear functional F  of the residual equation : 
%                 B0(eY,v) = F(v) - B(ux,v)
% where ux is the Q1 SGFEM approximation and eY,v reduced triquadratic (Q2) bubble functions
%[A,f] =  q1_3Dreducedq2_error_lhs_np(q,m,nc,norv,KL_DATA)
% input 
%      q          : index of multi-indices
%      m          : index of parameter under consideration
%      nc         : FEM levels for each multi-index
%      norv       : total number of parameters   
%      KL_DATA    : data related to KL-expansion
%
% outpt
%          A   : stiffness matrix
%          f   : rhs vector
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell


ncq = nc(q);
[ev,~,xyz,~] = grid_data3D(ncq);
nel = size(ev,1);
[~,~,mv,err_nodes,bound] = q1_error_connectivity_array(nel);
nvtx = max(mv(:));  % number of full q2 nodes in mesh excluding q1 vertices

x = xyz(:,1); y = xyz(:,2); z = xyz(:,3); 
A = sparse(nvtx,nvtx);
f = zeros(nvtx,1);

ngpt = 3; [oneg,onew] = gausspoints_oned(ngpt); [s,t,l,wt] = gausspoints_threed(oneg,onew); % setup quadrature for stiffness matrices
nngpt = ngpt^3;

A_local = zeros(nel,7,7); % initialise local LHS
f_local = zeros(nel,7); % initialise local RHS


xl_v = x(ev); yl_v = y(ev); zl_v = z(ev);

for igpt = 1:nngpt
    
    sigpt = s(igpt); tigpt = t(igpt); ligpt = l(igpt); wght = wt(igpt);
    
    [jac,invjac,~,~,~] = deriv3D(sigpt,tigpt,ligpt,xl_v,yl_v,zl_v);
    [phi,dphidx,dphidy,dphidz] = qderiv3D(sigpt,tigpt,ligpt,xl_v,yl_v,zl_v);
    
    coeff = stoch_gauss_coeff3D_m(sigpt,tigpt,ligpt,xl_v,yl_v,zl_v,norv,KL_DATA,m);
    rhs = stoch_gauss_source3D(sigpt,tigpt,ligpt,xl_v,yl_v,zl_v,0);
    
    % vectorised version
    f_local = f_local + wght*rhs(:).*phi(:,err_nodes).*jac(:);
    A_local = A_local + wght*coeff(:).*( dphidx(:,err_nodes).*permute(dphidx(:,err_nodes),[1 3 2]) + dphidy(:,err_nodes).*permute(dphidy(:,err_nodes),[1,3,2])+ dphidz(:,err_nodes).*permute(dphidz(:,err_nodes),[1,3,2]) ).*invjac(:);
    
end

% construct global matrix concatenating local ones

for krow = 1:7
    nrow = mv(:,krow);
    f(nrow,1) = f(nrow,1) + f_local(:,krow);
end

[Nrows,Ncols] = size(mv);
ncol = repmat(reshape(mv,Nrows*Ncols,1),7,1);


nrow = repmat(mv,Ncols,1);

A = sparse(nrow(:),ncol,A_local(:),nvtx,nvtx);

A(bound,:) = []; A(:,bound) = []; f(bound) = []; % apply zero dirichlet BCs and remove old nodes
end
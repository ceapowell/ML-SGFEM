function [s_data] = reducedq2_spatial_error_est3D(nc,indset,U,KL_DATA,G_data,s_data)
% REDUCEDQ2_SPATIAL_ERROR_EST3D a posteriori error estimations using global residual
% method with reduced triquadratic (Q2) spatial bubble functions in 3D
%[s_data] = reducedq2_spatial_error_est3D(nc,indset,U,KL_DATA,G_data,SG)
% input
%      nc         : FEM levels for each multi-index
%      indset     : index set
%      U          : SGFEM approximation
%      KL_DATA    : data related to KL-expansion
%      G_data     : Data for G matrices
%      s_data     : Spatial error approximation data
%
%
% outpt
%      s_data     :   Spatial error approximation data updated
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell

global iter_out

if iter_out == 1; fprintf('\nComputing spatial error estimate ... '); end


[P,~] = size(indset); % detemine quantity of multi-indices

[~,nz,~] = find(indset); noarv = max(nz);

b = cell(1,P);
s_data.error_vec = zeros(1,P);
for p = 1:P
    
    if isempty(s_data.A{nc(p)})
        if p == 1
             s_data.A{nc(1)} = q1_3Dreducedq2_error_lhs_np(1,0,nc,noarv,KL_DATA);
        else
             s_data.A{nc(p)} = q1_3Dreducedq2_error_lhs_np(p,0,nc,noarv,KL_DATA);
        end
    end
    
    dim_A = size(s_data.A{nc(p)},1); b{p} = zeros(dim_A,1);
    
     if dim_A ~= length(s_data.F) && p == 1
        [s_data.A{nc(1)},s_data.F] = q1_3Dreducedq2_error_lhs_np(1,0,nc,noarv,KL_DATA);
    end
    
    % ((2.^(nc(p)+1))-1).^2 -(2.^nc(p)-1).^2;
    Gp = G_data(p,:);
    for m = 0:noarv
        if isempty(Gp{m+1}) == 0; qi = Gp{m+1}(:,1); gi = Gp{m+1}(:,2);
            for i = 1:length(gi)
                if isempty(s_data.K{nc(qi(i)),nc(p),m+1})
                    [s_data.K{nc(qi(i)),nc(p),m+1}] = q1_3Dreducedq2_error_rhs_np(qi(i),p,m,nc,noarv,KL_DATA);
                end
                b{p} = b{p} - gi(i)*( U{qi(i)}'*s_data.K{nc(qi(i)),nc(p),m+1} )'; % transposing two vectors is cheaper than transposing K once
            end
        end
    end
   
end

% Computing the term F(v) = int_D\int_Gamma f(x)\psi_{0}(y)dy 
[~,s_data.F] = q1_3Dreducedq2_error_lhs_np(1,0,nc,noarv,KL_DATA);
b{1} = b{1} + s_data.F;  %only nonzero when current index is the zero index with no RV, i.e. m = 0


NC = unique(nc);
for i = 1:length(NC)
    
    NCi = find(nc == NC(i));
    RHS = cell2mat(b(NCi));
    x0=zeros(size(RHS));
  
    for j = 1:length(NCi)
        [lhs(:,j),flag,~,iter] = pcg(s_data.A{NC(i)},RHS(:,j),1e-8,100,[],[],x0(:,j));
        
    end

    s_data.error_vec(NCi) = dot(lhs,cell2mat(b(:,NCi))); % possibly marginally slower than above
    % loop
    
    clear lhs
end


s_data.error_est = norm(sqrt(s_data.error_vec),2);

if iter_out == 1; cprintf('-text','completed\n'); fprintf('  Spatial error estimate = %5.4e.\n',s_data.error_est); end
function [A] = q1_fullq2_error_rhs_np_nonequal_1(q,r,m,nc,norv,KL_DATA)
% Q1_FULLQ2_ERROR_RHS_NQ_NONEQUAL_1 computes stiffness matrix of the internal residual
% B(ux,v) for  non-equal grid levels (ux Q1 SGFEM solution defined in coarse mesh)
% v full triquadratic (Q2) bubble  functions
%[A] = q1_fullq2_error_rhs_np_nonequal_1(q,r,m,nc,norv,KL_DATA)
% input
%
%      q,r        : index of multi-indices
%      m          : index of parameter under consideration
%      nc         : FEM levels for each multi-index
%      norv       : total number of parameters
%      KL_DATA    : data related to KL-expansion
%
% outpt
%          A      : stiffness matrix
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell

ncq = nc(q); % solution level
ncr = nc(r); % error `detail' level

[ev_q,~,xyz_q,bound_sol3D] = grid_data3D(ncq);
[ev_r,~,xyz_r] = grid_data3D(ncr);

nel_q = length(ev_q(:,1)); % number of coarse elements
nel_r = length(ev_r(:,1)); % number of fine elements

[mv,bound_detail] = q1_error_connectivity_array(nel_r);

nvtx_q = size(xyz_q,1); % number of coarse and fine DOF

nvtx_r = max(mv(:)); % number of full q2 nodes in mesh excluding vertices

x_q = xyz_q(:,1); y_q = xyz_q(:,2); z_q = xyz_q(:,3); % coarse data
xl_q = x_q(ev_q); yl_q = y_q(ev_q); zl_q = z_q(ev_q);

x_r = xyz_r(:,1); y_r = xyz_r(:,2); z_r = xyz_r(:,3); % fine data
xl_r = x_r(ev_r); yl_r = y_r(ev_r); zl_r = z_r(ev_r);

lev_diff = abs(ncq-ncr);
n_subel = (2^lev_diff)^3; % determine how many fine elements per coarse element - minimum is four if levels are not equal

el_save = fine_el_retrieval(nel_q,nel_r); % this is the numbering of the fine elements which sit in each coarse element

ngpt = 3; [oneg,onew] = gausspoints_oned(ngpt); [s,t,l,wt] = gausspoints_threed(oneg,onew); nngpt=ngpt^3;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% new approach
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

coarse_x_vec = repmat(xl_q,n_subel,1);
coarse_y_vec = repmat(yl_q,n_subel,1);
coarse_z_vec = repmat(zl_q,n_subel,1);

fine_x = xl_r(el_save,:);
fine_y = yl_r(el_save,:);
fine_z = zl_r(el_save,:);

[ref_nodes_x, ref_nodes_y, ref_nodes_z] = boundary_transform3D_squ_vec(coarse_x_vec,coarse_y_vec,coarse_z_vec,fine_x,fine_y,fine_z);

phi_stl = vshape3D(s,t,l);
s_trans = ref_nodes_x*phi_stl; t_trans = ref_nodes_y*phi_stl; l_trans = ref_nodes_z*phi_stl;

a_small = zeros(nel_r,19,8);

for igpt = 1:nngpt
    
    sigpt = s(igpt); tigpt = t(igpt); ligpt = l(igpt); wght = wt(igpt);
    
    [~,invjac_c,~,dphidx_c,dphidy_c,dphidz_c] = vderiv3D(s_trans(:,igpt),t_trans(:,igpt),l_trans(:,igpt),coarse_x_vec,coarse_y_vec,coarse_z_vec);
    [~,dphidx_f,dphidy_f,dphidz_f] = qderiv3D(sigpt,tigpt,ligpt,fine_x,fine_y,fine_z);
    
    coeff = stoch_gauss_coeff3D_m(sigpt,tigpt,ligpt,fine_x,fine_y,fine_z,norv,KL_DATA,m);
    
    for j = 1:19
        for i = 1:8
            a_small(:,j,i) = a_small(:,j,i) + wght(1)*coeff(:).*(dphidx_c(:,i).*dphidx_f(:,j+8)+dphidy_c(:,i).*dphidy_f(:,j+8)+dphidz_c(:,i).*dphidz_f(:,j+8)).*invjac_c(:);
        end
    end
    
end

row_index = repmat(repmat(ev_q,n_subel,1),19,1);
col_index = repmat(mv(el_save,:),1,8);

A = sparse(row_index(:),col_index(:),a_small(:),nvtx_q,nvtx_r);

A(bound_sol3D,:) = [];
A(:,bound_detail) = [];
end
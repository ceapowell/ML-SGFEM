function [A] = q1_3Dfullq2_error_rhs_np_equal(q,m,nc,norv,KL_DATA)
% Q1_3DFULLQ2_ERROR_RHS_NQ_EQUAL computes stiffness matrix of the internal residual B(ux,v) for
% grids at the same level (implementing using full triquadratic(Q2(h)) bubble functions for the error estimation)
%[A] = q1_3Dfullq2_error_rhs_np_equal(q,m,nc,norv,KL_DATA)
% input
%
%      q          : index of multi-index
%      m          : index of parameter under consideration
%      nc         : FEM levels for each multi-index
%      norv       : total number of parameters
%      KL_DATA    : data related to KL-expansion
%
% outpt
%          A   : stiffness matrix
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell

ncq = nc(q);

[ev,~,xyz,bound_sol3D] = grid_data3D(ncq);

nel = size(ev,1);

[mv,bound3D] = q1_error_connectivity_array(nel);

nvtx = max(mv(:)); % number of full q2 nodes in mesh excluding vertices
nvtx_sol3D = size(xyz,1);

x = xyz(:,1); y = xyz(:,2); z = xyz(:,3);
A = sparse(nvtx_sol3D,nvtx);

ngpt = 3; [oneg,onew] = gausspoints_oned(ngpt); [s,t,l,wt] = gausspoints_threed(oneg,onew); % setup quadrature for stiffness matrices
nngpt = ngpt^3;

A_local = zeros(nel,8,19); % initialise local LHS

xl_v = x(ev); yl_v = y(ev); zl_v = z(ev);

for igpt = 1:nngpt
    
    sigpt = s(igpt); tigpt = t(igpt); ligpt = l(igpt); wght = wt(igpt);
    
    [~,invjac,~,dphidx,dphidy,dphidz] = deriv3D(sigpt,tigpt,ligpt,xl_v,yl_v,zl_v);
    [~,dphidx2,dphidy2,dphidz2] = qderiv3D(sigpt,tigpt,ligpt,xl_v,yl_v,zl_v);
    
    coeff = stoch_gauss_coeff3D_m(sigpt,tigpt,ligpt,xl_v,yl_v,zl_v,norv,KL_DATA,m);
    
    A_local = A_local + wght*coeff(:).*( dphidx.*permute(dphidx2(:,9:27),[1 3 2]) + dphidy.*permute(dphidy2(:,9:27),[1,3,2]) + dphidz.*permute(dphidz2(:,9:27),[1,3,2]) ).*invjac(:);
    
    
end
[Nrows,Ncols] = size(ev);
nrow = repmat(reshape(ev,Nrows*Ncols,1),19,1);

ncol = repmat(mv,Ncols,1);

A = sparse(nrow,ncol(:),A_local(:),nvtx_sol3D,nvtx);

A(bound_sol3D,:) = []; A(:,bound3D) = []; % apply zero dirichlet BCs
end
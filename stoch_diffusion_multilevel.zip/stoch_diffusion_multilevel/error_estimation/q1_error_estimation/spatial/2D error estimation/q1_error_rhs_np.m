function [A] = q1_error_rhs_np(q,r,m,nc,norv,KL_DATA)
% Q1_ERROR_RHS_NP computes stiffness matrix of the bilinear form B(ux,v) 
%for equal and different mesh levels of the right hand side of the residual equation :
%                  B0(eY,v) = F(v) - B(ux,v)
% where ux is the Q1  ML SGFEM approximation and eY,v are biquadratic (Q2) bubble functions 
%[A] =  q1_error_rhs_np(q,r,m,nc,norv,KL_DATA)
% input 
%       q,r     : multi-indices q,r
%       m       : index of parameter under consideration
%       nc      : FEM levels for each multi-index
%       norv    : total number of parameters
%       KL_DATA : data from KL expansion, needed for stiffness matrices
%
% outpt
%       A   : stiffness matrix
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell


ncq = nc(q); % solution level
ncr = nc(r); % error `detail' level

% construct deterministic matrices
if ncq == ncr % mu and nu are on the same FEM level (default SGFEM)
    [A] = q1_error_rhs_np_equal(q,m,nc,norv,KL_DATA);
else
    if ncq < ncr
        [A] = q1_error_rhs_np_nonequal_1(q,r,m,nc,norv,KL_DATA);
    else
        [A] = q1_error_rhs_np_nonequal_2(q,r,m,nc,norv,KL_DATA);
    end
    
end



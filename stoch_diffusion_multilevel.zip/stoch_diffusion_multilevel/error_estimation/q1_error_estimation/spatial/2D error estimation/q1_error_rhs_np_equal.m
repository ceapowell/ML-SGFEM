function [A] = q1_error_rhs_np_equal(q,m,nc,norv,KL_DATA)
% Q1_ERROR_RHS_NQ computes stiffness matrix of the internal residual B(ux,v) for
% grids at the same level
%[A] = q1_error_rhs_np_equal(q,m,nc,norv,KL_DATA)
% input
%
%      q          : index of multi-index
%      m          : index of parameter under consideration
%      nc         : FEM levels for each multi-index
%      norv       : total number of parameters
%      KL_DATA    : data related to KL-expansion
%
% outpt
%          A   : stiffness matrix
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell

% implementing Q2(h) error estimation
global dom_type;
ncq = nc(q);

[ev,~,xy,bound_sol] = grid_data(ncq);

nel = size(ev,1);

[mv,bound] = q1_error_connectivity_array(nel);



if isequal(dom_type,'square')
    nvtx = sqrt(nel)*(2*sqrt(nel) + 1) + sqrt(nel)*(sqrt(nel) + 1); % number of q2 nodes in mesh excluding vertices
else
    nvtx = max(mv(:));  %sqrt(nel/3)*(2*sqrt(nel/3) + 1) + sqrt(nel/3)*(sqrt(nel/3) + 1); % number of q2 nodes in mesh excluding vertices
end
nvtx_sol = size(xy,1);

x = xy(:,1); y = xy(:,2);
A = sparse(nvtx_sol,nvtx);

ngpt = 3; [oneg,onew] = gausspoints_oned(ngpt); [s,t,wt] = gausspoints_twod(oneg,onew); % setup quadrature for stiffness matrices
nngpt = ngpt^2;

A_local = zeros(nel,4,5); % initialise local LHS

xl_v = x(ev); yl_v = y(ev);

for igpt = 1:nngpt
    
    sigpt = s(igpt); tigpt = t(igpt); wght = wt(igpt);
    
    [~,invjac,~,dphidx,dphidy] = deriv(sigpt,tigpt,xl_v,yl_v);
    [~,dphidx2,dphidy2] = qderiv(sigpt,tigpt,xl_v,yl_v);
    
    coeff = stoch_gauss_coeff_m(sigpt,tigpt,xl_v,yl_v,norv,KL_DATA,m);
    
    A_local = A_local + wght*coeff(:).*( dphidx.*permute(dphidx2(:,5:9),[1 3 2]) + dphidy.*permute(dphidy2(:,5:9),[1,3,2]) ).*invjac(:);
    
    
end

[Nrows,Ncols] = size(ev);
nrow = repmat(reshape(ev,Nrows*Ncols,1),5,1);

ncol = repmat(mv,Ncols,1);

A = sparse(nrow,ncol(:),A_local(:),nvtx_sol,nvtx);

A(bound_sol,:) = []; A(:,bound) = []; % apply zero dirichlet BCs
end



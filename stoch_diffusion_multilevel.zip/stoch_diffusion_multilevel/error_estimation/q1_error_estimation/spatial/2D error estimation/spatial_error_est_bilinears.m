function [s_data,SG_main] = spatial_error_est_bilinears(nc,indset,U,KL_DATA,G_data,s_data,SG_main)
% SPATIAL_ERROR_EST a posteriori error estimations using global residual
% method with  bilinear (Q1(h/2)) bubble functions on refined mesh excluding
% Q1 SGFEM solution nodes
%[s_data,SG_main] = spatial_error_est_bilinears(nc,indset,U,KL_DATA,G_data,SG,SG_main)
% input
%      nc         : FEM levels for each multi-index
%      indset     : index set
%      U          : SGFEM approximation
%      KL_DATA    : data related to KL-expansion
%      G_data     : Data for G matrices
%      s_data         : Spatial error approximation data
%      SG_main    : Solution approximation data
%
%
% outpt
%      SG         :   Spatial error approximation data updated
%      SG_main    :   Solution approximation data updated
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell
global iter_out dom_type

if iter_out == 1; fprintf('\nComputing spatial error estimate ... '); end

[P,~] = size(indset); % detemine quantity of multi-indices
[~,nz,~] = find(indset); noarv = max(nz);

b = cell(1,P);
s_data.error_vec = zeros(1,P);
for p = 1:P
    if isequal(dom_type, 'square')
        len_p = ((2.^(nc(p)+1))-1).^2;
        temp = reshape(1:len_p, sqrt(len_p),sqrt(len_p));
        keep_positions_p = setdiff(1:len_p,temp(2:2:end,2:2:end));
    else  % Lshape domain
        
        len_p1 = ((2.^(nc(p)))-1).^2;
        temp1 = reshape(1:len_p1, sqrt(len_p1),sqrt(len_p1));
        keep_positions_p1 = setdiff(1:len_p1,temp1(2:2:end,2:2:end));
        
        len_p2 = len_p1+ ((2.^(nc(p)))-1).^2;
        temp2 = reshape((len_p1+1):len_p2, sqrt(len_p1),sqrt(len_p1));
        keep_positions_p2 = setdiff((len_p1+1):len_p2,temp2(2:2:end,2:2:end));
        
        len_p3 = len_p2 +(2.^(nc(p)))-1;
        
        v = (len_p2+1):len_p3;
        temp3 = v;
        
        keep_positions_p3 = setdiff(v,temp3(2:2:end));
        
        len_p4 = len_p3 +(2.^(nc(p))).^2-2^(nc(p));
        v = (len_p3+1):len_p4;
        temp4 = reshape(v,2^(nc(p)),[])';
        keep_positions_p4 = setdiff(v,temp4(2:2:end,1:2:end));
        
        keep_positions_p = [keep_positions_p1 keep_positions_p2 keep_positions_p3 keep_positions_p4];
        
    end
    
    
    % Compute F
    if p == 1 && isempty(s_data.F{nc(1)})
        [~,s_data.F{nc(1)}] = mu_nu_stiffness(nc(1)+1,nc(1)+1,0,nc,noarv,KL_DATA);
        s_data.F{nc(1)} = s_data.F{nc(1)}(keep_positions_p);
    end
    
    if isequal(dom_type, 'square')
        dim_A = ((2.^(nc(p)+1))-1).^2 -(2.^nc(p)-1).^2;
    else
        dim_A = length(keep_positions_p);% sqrt((nc(p)+1)/3)*(2*sqrt((nc(p)+1)/3) + 1) + sqrt((nc(p)+1)/3)*(sqrt((nc(p)+1)/3) + 1);
    end
    b{p} = zeros(dim_A,1);
    Gp = G_data(p,:);
    for m = 0:noarv
        if isempty(Gp{m+1}) == 0; qi = Gp{m+1}(:,1); gi = Gp{m+1}(:,2);
            for i = 1:length(gi)
                if isempty(SG_main.K{nc(qi(i)),nc(p)+1,m+1})
                    SG_main.K{nc(qi(i)),nc(p)+1,m+1} = mu_nu_stiffness(nc(qi(i)),nc(p)+1,m,nc,noarv,KL_DATA);
                    SG_main.K{nc(p)+1,nc(qi(i)),m+1} = SG_main.K{nc(qi(i)),nc(p)+1,m+1}';
                end
                b{p} = b{p} - gi(i)*( U{qi(i)}'*SG_main.K{nc(qi(i)),nc(p)+1,m+1}(:,keep_positions_p) )'; % bilinears, excluding old nodes
            end
        end
    end
    
    if p == 1; b{1} = b{1} + s_data.F{nc(1)}; end % only nonzero when current index is the zero index with no RV, i.e. m = 0
    
end

% vectorise solves over grid levels
NC = unique(nc);

if isempty(SG_main.K{NC(end)+1,NC(end)+1,1})
    [SG_main.K{NC(end)+1,NC(end)+1,1},SG_main.F{NC(end)+1}] = mu_nu_stiffness(NC(end)+1,NC(end)+1,0,nc,noarv,KL_DATA);
end

for i = 1:length(NC)
    
    NCi = find(nc == NC(i)); RHS = cell2mat(b(NCi));
    if isequal(dom_type, 'square')
        len_i = ((2.^(NC(i)+1))-1).^2; temp = reshape(1:len_i,sqrt(len_i),sqrt(len_i))';
        keep_positions_i = setdiff(1:len_i,temp(2:2:end,2:2:end));
        
    else
        len_p1 = ((2.^(NC(i)))-1).^2;
        temp1 = reshape(1:len_p1, sqrt(len_p1),sqrt(len_p1));
        keep_positions_p1 = setdiff(1:len_p1,temp1(2:2:end,2:2:end));
        
        len_p2 = len_p1+ ((2.^(NC(i)))-1).^2;
        temp2 = reshape((len_p1+1):len_p2, sqrt(len_p1),sqrt(len_p1));
        keep_positions_p2 = setdiff((len_p1+1):len_p2,temp2(2:2:end,2:2:end));
        
        len_p3 = len_p2 +(2.^(NC(i)))-1;
        
        v = (len_p2+1):len_p3;
        temp3 = v;
        
        keep_positions_p3 = setdiff(v,temp3(2:2:end));
        
        len_p4 = len_p3 +(2.^(NC(i))).^2-2^(NC(i));
        v = (len_p3+1):len_p4;
        temp4 = reshape(v,2^(NC(i)),[])';
        keep_positions_p4 = setdiff(v,temp4(2:2:end,1:2:end));
        
        keep_positions_i = [keep_positions_p1 keep_positions_p2 keep_positions_p3 keep_positions_p4];
    end
    if isempty(s_data.DA{NC(i)})
        s_data.DA{NC(i)} = decomposition(SG_main.K{NC(i)+1,NC(i)+1,1}(keep_positions_i,keep_positions_i),'chol');
    end
    
    lhs = s_data.DA{NC(i)}\RHS;
    s_data.error_vec(NCi) = dot(lhs,cell2mat(b(:,NCi))); % possibly marginally slower than above
    
    
end

s_data.error_est = norm(sqrt(s_data.error_vec),2);

if iter_out == 1; cprintf('-text','completed\n'); fprintf('  Spatial error estimate = %5.4e.\n',s_data.error_est); end






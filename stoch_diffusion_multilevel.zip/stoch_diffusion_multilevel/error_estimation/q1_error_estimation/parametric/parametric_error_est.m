function [SG,K] = parametric_error_est(nc,nc_max,ad_rv,norv,P_indset,U,KL_DATA,P_indset_old,enrich_loc,SG,DA,K)
% PARAMETRIC_ERROR_EST a posteriori error estimations for stochastic Q1 solution using global residual
% method on finer index set Q 
%[SG,K] = parametric_error_est(nc,nc_max,ad_rv,norv,P_indset,U,KL_DATA,P_indset_old,enrich_loc,SG,DA,K)
% input 
%      nc           : FEM levels for each multi-index
%      nc_max       : max FEM level
%      ad_rv        : extra parameters for the parametric error estimation
%      norv         : total number of parameters
%      P_indset     : Inhex set JP
%      U            : SGFEM approximation 
%      KL_data      : data related to KL-expansion
%      P_indset_old : Old index set JP
%      enrich_loc   : Indices locations with the highest error 
%      SG           : Parametric error approximation data
%      DA           : K0 Cholesky decomp
%      K            : LHS FEM matrices
%
%
% outpt
%      SG           : Parametric error approximation data updated  
%      K            : stiffness matrices 
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell

global TP iter_out dom_type

if iter_out == 1; fprintf('\nComputing parametric error estimate ... '); end

[~,nz,~] = find(P_indset); noarv = max(nz);

% [P,~] = size(P_indset);

if all(nc == max(nc))
    [~,ncq] = min(nc);
else
    un_nc = unique(nc);
    H = cumsum(hist(nc,un_nc));
    temp = find(H >= H(end)/2);
    nc_val = un_nc(temp(1));
    nc_loc = find(nc == nc_val);
    
    ncq = nc_loc(1);
end

NCQ = nc(ncq);

if norv - noarv < ad_rv + 1
    error(' The algorithm needs to activate more random variables than the maximum number currently allowed. Please increase norv in stoch_adapt_ML_SGFEM')
else
    if TP == 1 && KL_DATA.ev2d(noarv + ad_rv + 1) == KL_DATA.ev2d(noarv + ad_rv) % ensure to include pairs of RV's
        additional_RV = ad_rv + 1;
    else
        additional_RV = ad_rv;
    end
end

noarvx = noarv + additional_RV;


if SG.p_refine == 1
    [SG.GPQ_data,SG.Q_indset] = adapt_stoch_gmatrices_error(SG.GPQ_data,P_indset,P_indset_old,SG.Q_indset,noarvx,norv,enrich_loc,additional_RV);
end

Q = size(SG.Q_indset,1); 

if isequal(dom_type,'square')
     N = (2.^NCQ-1).^2;
else
     N = (2.^NCQ-1).^2 -2.^(2.*NCQ-2);
end

b = zeros(N,Q);

for q = 1:Q; Gq = SG.GPQ_data(q,:);
    for m = 1:noarvx
        if isempty(Gq{m}) == 0
            pi = Gq{m}(:,1); 
            gi = Gq{m}(:,2);
            % By construction, gi,pi can be at most scalars
       
            if isempty(K{NCQ,nc(pi),m+1})
                K{NCQ,nc(pi),m+1} = mu_nu_stiffness(NCQ,nc(pi),m,nc,noarvx,KL_DATA); 
                K{nc(pi),NCQ,m+1} = K{NCQ,nc(pi),m+1}';
            end
            b(:,q) = b(:,q) - gi*( K{NCQ,nc(pi),m+1}*U{pi} );
            
        end
    end
end

% Da = decomposition(SG.A,'chol');
E = DA{NCQ}\b; % vectorised solve for each parametric error estimator

SG.error_vec = dot(E,b); % dot computes the dot-prod of the columns of E and b, no need for loop.
SG.error_est = norm(sqrt(SG.error_vec),2);
SG.ncq = ncq;

if iter_out == 1; cprintf('-text','completed\n'); fprintf('  Parametric error estimate = %5.4e.\n',SG.error_est); end


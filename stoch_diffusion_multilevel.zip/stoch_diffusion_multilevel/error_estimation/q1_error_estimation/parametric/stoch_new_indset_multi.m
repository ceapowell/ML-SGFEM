function [Bunq,B,JJ] = stoch_new_indset_multi(A,noarv,norv,Delta_M)
% STOCH_NEW_INDSET_MULTI this function adds new  multi-indices    
%[Bunq,B,JJ] = stoch_new_indset_multi(A,noarv,norv,dd)
% input 
%      A            : Multi-index set
%      noarv        : largest number of the actived parameter in the index set
%      norv         : total number of parameters
%      Delta_M      : extra parameters for the parametric error estimation
%
% outpt
%      Bunq         : New multi-index without duplicate values  
%      B            : New multi-index with duplicate values  
%      JJ           : index vector such that B = Bunq(JJ,:). 
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell

% check that noarv < norv
if noarv >= norv, error('error: increase the number of random variables!'), end

I = eye(noarv+Delta_M,'uint8');

B = [];
for m = 1:noarv + Delta_M
    B = [B; A(:,1:noarv+Delta_M)+I(m,:)];
end

% Cancel duplicating rows in B and reinstate zeros 
[Bunq,~,JJ] = unique(B(1:size(B,1),:),'rows'); Bunq = [Bunq,zeros(size(Bunq,1),norv-noarv-Delta_M)];

end


function [total_deg] = stoch_indset(p,norv)
%STOCH_INDSET  fast computation of total degree index set
%
%   [total_deg] = stoch_indset(p,norv)
%   inputs:
%          norv          number of random variables
%          p             polynomial degree
%   output:
%          total_deg     index set for multivariable polynomials of total degree <=p
%
% calls the function genindex
% SIFISS function: CEP; 21 May 2015.
% Copyright (c) 2015 A. Bespalov, C.E. Powell, D.J. Silvester

total_deg=[];
for i=0:p
    % find multi-indices of length norv that sum to exactly i
total_deg=[total_deg;genindex(norv,i)];
end
total_deg=uint8(total_deg);

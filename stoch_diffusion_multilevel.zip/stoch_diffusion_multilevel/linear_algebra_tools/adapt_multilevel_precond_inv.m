function b = adapt_multilevel_precond_inv(x,nc,G_data,K,DA,noarv,nterms)
% ADAPT_MULTILEVEL_PRECOND_INV  applies mean-based preconditioner to vector
%[b] =  adapt_multilevel_precond_inv(x,nc,G_data,K,DA,noarv,nterms)
% input
%      x           : input vector
%      nc         : FEM levels for each multi-index
%      G_data     : stochastic G-matrices
%      K          : stifness Matrices
%      DA         : Cholescky decomposition
%      nterms     : Number of terms in precond expansion (1 = mean-based preconditioning)
% outpt
%      b          :  Outpt vector
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell

temp = A0_inv(x,nc,DA); b = temp;
for i = 1:nterms-1
    temp = A0_inv(multilevel_matvec_prod_nomean(temp,G_data,K,noarv,nc),nc,DA);
    b = b + ((-1)^i)*temp;
end

end

function b = A0_inv(x,nc,DA)
global dom_type

if isequal(dom_type,'square')
    N = (2.^nc-1).^2; % number of internal (solution) nodes per level
elseif isequal(dom_type,'Lshape')
    N = (2.^nc-1).^2 -2.^(2.*nc-2);
else%if isequal(dom_type,'cube')
    N = (2.^nc-1).^3; % number of internal (solution) nodes per level
end
x_split = mat2cell(x,N,1)';

NC = unique(nc);
LHS = cell(length(nc),1);

for i = 1:length(NC)
    
    NCi = find(nc == NC(i));
    RHS = cell2mat(x_split(NCi)); % locate vectors associated with grid level NC(i)
    if isequal(dom_type,'square') || isequal(dom_type,'Lshape')
        lhs = DA{NC(i)}\RHS; % compute a vectorised solve
        
        [N1,N2] = size(lhs); LHS(NCi) = mat2cell(lhs,N1,ones(1,N2));
        
    else
        x0=zeros(size(RHS));
        for j = 1:length(NCi)
            [lhs(:,j),flag,~,iter] = pcg(DA{NC(i)},RHS(:,j),1e-8,100,[],[],x0(:,j));
        end
        for j = 1:length(NCi)
            LHS{NCi(j)} = lhs(:,j);
        end
        clear lhs
    end
end

b = cell2mat(LHS);

end

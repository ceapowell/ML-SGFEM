function b = multilevel_matvec_prod(x,G_data,K,noarv,nc)
%MULTILEVEL_MATVEC computes efficiently  product  between multilevel
%matrices and vectors 
%   b = multilevel_matvec_prod(x,G_data,K,noarv,nc)
%   input
%          x      : input vector  
%          G_data : Data for stochastic G matrices
%          K      : LHS FEM matrices
%          noarv  : number of active parameters
%          nc     : FEM grid levels
%   output
%          b      : output vector 
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell

global  dom_type
if isequal(dom_type,'square')
    N = (2.^nc-1).^2; % number of internal (solution) nodes per level
elseif isequal(dom_type,'Lshape')
    N = (2.^nc-1).^2 -2.^(2.*nc-2);
else
    N = (2.^nc-1).^3; % number of internal (solution) nodes per level  
end
x_ind = [1,cumsum(N)+1]; b = zeros(N(end),1);

for q = 1:length(nc) % compute the q^th block of the matrix vector product
    
    Q = G_data(q,:); z = zeros(N(q),1);
    
    for m = 0:noarv
        if isempty(Q{m+1}) == 0; ri = Q{m+1}(:,1); gi = Q{m+1}(:,2);
            for i = 1:length(ri)
                z = z + gi(i)*( K{nc(q),nc(ri(i)),m+1} * x( x_ind(ri(i)) : x_ind(ri(i)+1)-1  ) );
            end
        end
    end
    
    b( x_ind(q) : x_ind(q+1)-1 ) = z;
    
end


end


function [mv,bound,NODES] = q2_error_connectivity_array(nel)
% Q2_ERROR_CONNECTIVITY_ARRAY generates full Q4 connectivity array excluding vertex nodes
% 16 nodes  per element.
% [mv,bound] = q2_error_connectivity_array(nel)
% input
%      nel   : number of elements
%
% outpt
%      mv    : Q4 macroelement mapping matrix
%      bound : boundary vertex vector
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell

% number of q2 nodes in mesh excluding vertices
% n_nodes = sqrt(nel)*(2*sqrt(nel) + 1) + sqrt(nel)*(sqrt(nel) + 1);

global dom_type;

if isequal(dom_type,'square')
    
    NODES = zeros(2*sqrt(nel)+1,2*sqrt(nel)+1);
    
    ind_end = 0;
    for i = 1:2*sqrt(nel)+1
        if rem(i,2) == 0
            keep = ind_end+1:ind_end+2*sqrt(nel)+1;
            ind_end = ind_end+2*sqrt(nel)+1;
            NODES(i,1:end) = keep;
        else
            keep = ind_end+1:ind_end+sqrt(nel);
            ind_end = ind_end+sqrt(nel);
            NODES(i,2:2:end) = keep;
        end
        
    end
    
    mv(:,1) = reshape(NODES(1:4:end-1,2:4:end)',[],1);
    mv(:,2) = reshape(NODES(1:4:end-1,4:4:end)',[],1);
    mv(:,3) = reshape(NODES(2:4:end-1,5:4:end)',[],1);
    mv(:,4) = reshape(NODES(4:4:end-1,5:4:end)',[],1);
    mv(:,5) = reshape(NODES(5:4:end,4:4:end)',[],1);
    mv(:,6) = reshape(NODES(5:4:end,2:4:end)',[],1);
    mv(:,7) = reshape(NODES(4:4:end-1,1:4:end-1)',[],1);
    mv(:,8) = reshape(NODES(2:4:end-1,1:4:end-1)',[],1);
    mv(:,9) = reshape(NODES(2:4:end-1,2:4:end-1)',[],1);
    mv(:,10) = reshape(NODES(2:4:end-1,3:4:end-1)',[],1);
    mv(:,11) = reshape(NODES(2:4:end-1,4:4:end-1)',[],1);
    mv(:,12) = reshape(NODES(3:4:end-1,4:4:end-1)',[],1);
    mv(:,13) = reshape(NODES(4:4:end-1,4:4:end-1)',[],1);
    mv(:,14) = reshape(NODES(4:4:end-1,3:4:end-1)',[],1);
    mv(:,15) = reshape(NODES(4:4:end-1,2:4:end-1)',[],1);
    mv(:,16) = reshape(NODES(3:4:end-1,2:4:end-1)',[],1);
    
    nodes_on_boundary = unique([NODES(1,:) NODES(end,:) NODES(:,1)' NODES(:,end)']);
    bound = nodes_on_boundary(2:end); % dont need node `zero'
    
elseif isequal(dom_type,'Lshape')
    
    NODES = zeros(2*sqrt(nel/3)+1,2*sqrt(nel/3));
    
    ind_end = 0;
    for i = 1:2*sqrt(nel/3)+1
        if rem(i,2) == 0
            keep = ind_end+1:ind_end+2*sqrt(nel/3);
            ind_end = ind_end+2*sqrt(nel/3);
            NODES(i,1:end) = keep;
        else
            keep = ind_end+1:ind_end+sqrt(nel/3);
            ind_end = ind_end+sqrt(nel/3);
            NODES(i,2:2:end) = keep;
        end
        
    end
    
    NODES = [NODES, zeros(size(NODES,1),1)];
    
    
    NODES2 = zeros(4*sqrt(nel/3)+1,2*sqrt(nel/3)+1);
    
    
    for i = 1:4*sqrt(nel/3)+1
        if rem(i,2) == 0
            keep = ind_end+1:ind_end+2*sqrt(nel/3)+1;
            ind_end = ind_end+2*sqrt(nel/3)+1;
            NODES2(i,1:end) = keep;
        else
            keep = ind_end+1:ind_end+sqrt(nel/3);
            ind_end = ind_end+sqrt(nel/3);
            NODES2(i,2:2:end) = keep;
        end
        
    end
    
    NODES(:,end) = NODES2(2*sqrt(nel/3)+1:end,1);
    %  NODES = [NODES;NODES2];
    
    
    mv(:,1) = reshape(NODES(1:4:end-1,2:4:end)',[],1);
    mv(:,2) = reshape(NODES(1:4:end-1,4:4:end)',[],1);
    mv(:,3) = reshape(NODES(2:4:end-1,5:4:end)',[],1);
    mv(:,4) = reshape(NODES(4:4:end-1,5:4:end)',[],1);
    mv(:,5) = reshape(NODES(5:4:end,4:4:end)',[],1);
    mv(:,6) = reshape(NODES(5:4:end,2:4:end)',[],1);
    mv(:,7) = reshape(NODES(4:4:end-1,1:4:end-1)',[],1);
    mv(:,8) = reshape(NODES(2:4:end-1,1:4:end-1)',[],1);
    mv(:,9) = reshape(NODES(2:4:end-1,2:4:end-1)',[],1);
    mv(:,10) = reshape(NODES(2:4:end-1,3:4:end-1)',[],1);
    mv(:,11) = reshape(NODES(2:4:end-1,4:4:end-1)',[],1);
    mv(:,12) = reshape(NODES(3:4:end-1,4:4:end-1)',[],1);
    mv(:,13) = reshape(NODES(4:4:end-1,4:4:end-1)',[],1);
    mv(:,14) = reshape(NODES(4:4:end-1,3:4:end-1)',[],1);
    mv(:,15) = reshape(NODES(4:4:end-1,2:4:end-1)',[],1);
    mv(:,16) = reshape(NODES(3:4:end-1,2:4:end-1)',[],1);
    
    
    mvv(:,1) = reshape(NODES2(1:4:end-1,2:4:end)',[],1);
    mvv(:,2) = reshape(NODES2(1:4:end-1,4:4:end)',[],1);
    mvv(:,3) = reshape(NODES2(2:4:end-1,5:4:end)',[],1);
    mvv(:,4) = reshape(NODES2(4:4:end-1,5:4:end)',[],1);
    mvv(:,5) = reshape(NODES2(5:4:end,4:4:end)',[],1);
    mvv(:,6) = reshape(NODES2(5:4:end,2:4:end)',[],1);
    mvv(:,7) = reshape(NODES2(4:4:end-1,1:4:end-1)',[],1);
    mvv(:,8) = reshape(NODES2(2:4:end-1,1:4:end-1)',[],1);
    mvv(:,9) = reshape(NODES2(2:4:end-1,2:4:end-1)',[],1);
    mvv(:,10) = reshape(NODES2(2:4:end-1,3:4:end-1)',[],1);
    mvv(:,11) = reshape(NODES2(2:4:end-1,4:4:end-1)',[],1);
    mvv(:,12) = reshape(NODES2(3:4:end-1,4:4:end-1)',[],1);
    mvv(:,13) = reshape(NODES2(4:4:end-1,4:4:end-1)',[],1);
    mvv(:,14) = reshape(NODES2(4:4:end-1,3:4:end-1)',[],1);
    mvv(:,15) = reshape(NODES2(4:4:end-1,2:4:end-1)',[],1);
    mvv(:,16) = reshape(NODES2(3:4:end-1,2:4:end-1)',[],1);
    
    
    mv = [mv;mvv];
    
    nodes_on_boundary = unique([NODES(1,:) NODES2(:,1)'  NODES2(1,:) NODES2(:,end)' NODES(end,1:end-1) NODES2(end,:) NODES(:,1)']);
    bound = nodes_on_boundary(2:end);    
end

end

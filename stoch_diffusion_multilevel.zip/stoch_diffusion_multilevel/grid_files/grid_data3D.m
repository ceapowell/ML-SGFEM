function [ev,mv,xyz,bound3D] = grid_data3D(nc)
% GRID_DATA3D generates cube domain of size nc
%[ev,mv,xy,bound] = grid_data3D(nc)
% input
%      nc           : grid level
%
% outpt
%      ev           : element matrix
%      mv           : Macroelement matrix
%      xy           : vertex coordinate vector
%      bound        : boundary vertex vector
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell

global dom_type TP

if isequal(dom_type,'cube')
    
    steps = 2^nc; % number of elements in 1D
    h = 2^(-nc+1); % element width
    
    nvtx = (steps + 1)^3; % total number of nodes
    
    if TP == 1
        x = linspace(-1,1,steps+1); y = x;  z = x;% x, y and z coordinates in 1D TP2
    else
        x = linspace(0,1,steps+1);  y = x;  z = x;% x, y and z  coordinates in 1D TP5
    end
    
    [X,Y,Z] = meshgrid(x,y,z); % generate 2D mesh
    
    xx = reshape(X,nvtx,1); yy = reshape(Y,nvtx,1); zz = reshape(Z,nvtx,1);
    
    xyz = [xx(:),yy(:),zz(:)]; % store x,y and z coordinates of nodes (of which there are nvtx of them)
    
    nodes = reshape(1:nvtx,nthroot(nvtx,3),nthroot(nvtx,3),nthroot(nvtx,3)); % matrix reflecting node ordering
    
    nel = steps^3;
    ev = zeros(nel,8); % initialise connectivity array
    
    
    v1 = nodes(1:end-1,1:end-1,1:end-1); ev(:,1)=v1(:);
    v2 = nodes(2:end,1:end-1,1:end-1);   ev(:,2)=v2(:);
    v3 = nodes(2:end,1:end-1,2:end);     ev(:,3)=v3(:);
    v4 = nodes(1:end-1,1:end-1,2:end);   ev(:,4)=v4(:);
    v5 = nodes(1:end-1,2:end,1:end-1);   ev(:,5)=v5(:);
    v6 = nodes(2:end,2:end,1:end-1);     ev(:,6)=v6(:);
    v7 = nodes(2:end,2:end,2:end);       ev(:,7)=v7(:);
    v8 = nodes(1:end-1,2:end,2:end);     ev(:,8)=v8(:);
    
    
    mv(:,1) = reshape(nodes(1:2:end-1,1:2:end-1,1:2:end-1),[],1);
    mv(:,2) = reshape(nodes(3:2:end,1:2:end-1,1:2:end-1),[],1);
    mv(:,3) = reshape(nodes(3:2:end,1:2:end-1,3:2:end),[],1);
    mv(:,4) = reshape(nodes(1:2:end-1,1:2:end-1,3:2:end),[],1);
    mv(:,5) = reshape(nodes(1:2:end-1,3:2:end,1:2:end-1),[],1);
    mv(:,6) = reshape(nodes(3:2:end,3:2:end,1:2:end-1),[],1);
    mv(:,7) = reshape(nodes(3:2:end,3:2:end,3:2:end),[],1);
    mv(:,8) = reshape(nodes(1:2:end-1,3:2:end,3:2:end),[],1);
    mv(:,9) = reshape(nodes(2:2:end-1,1:2:end-1,1:2:end-1),[],1);
    mv(:,10) = reshape(nodes(3:2:end,2:2:end-1,1:2:end-1),[],1);
    mv(:,11) = reshape(nodes(2:2:end-1,3:2:end,1:2:end-1),[],1);
    mv(:,12) = reshape(nodes(1:2:end-1,2:2:end,1:2:end-1),[],1);
    mv(:,13) = reshape(nodes(2:2:end-1,2:2:end,1:2:end-1),[],1);
    mv(:,14) = reshape(nodes(2:2:end-1,1:2:end-1,2:2:end-1),[],1);
    mv(:,15) = reshape(nodes(3:2:end,1:2:end-1,2:2:end),[],1);
    mv(:,16) = reshape(nodes(3:2:end,2:2:end,2:2:end),[],1);
    mv(:,17) = reshape(nodes(3:2:end,3:2:end,2:2:end),[],1);
    mv(:,18) = reshape(nodes(2:2:end,3:2:end,2:2:end),[],1);
    mv(:,19) = reshape(nodes(1:2:end-1,3:2:end,2:2:end),[],1);
    mv(:,20) = reshape(nodes(1:2:end-1,2:2:end-1,2:2:end-1),[],1);
    mv(:,21) = reshape(nodes(1:2:end-1,1:2:end-1,2:2:end),[],1);
    mv(:,22) = reshape(nodes(2:2:end-1,2:2:end-1,2:2:end-1),[],1);
    mv(:,23) = reshape(nodes(2:2:end,1:2:end-1,3:2:end),[],1);
    mv(:,24) = reshape(nodes(3:2:end,2:2:end,3:2:end),[],1);
    mv(:,25) = reshape(nodes(2:2:end-1,3:2:end,3:2:end),[],1);
    mv(:,26) = reshape(nodes(1:2:end-1,2:2:end,3:2:end),[],1);
    mv(:,27) = reshape(nodes(2:2:end,2:2:end,3:2:end),[],1);
    
    
    corner_nodes = [nodes(1,1,1);.....
        nodes(end,1,1);.....
        nodes(end,1,end);.....
        nodes(1,1,end);......
        nodes(1,end,1);.....
        nodes(end,end,1);......
        nodes(end,end,end);....
        nodes(1,end,end)];
    f1_nodes  = reshape(nodes(1:end,1,1:end),[],1);
    f2_nodes = reshape(nodes(end,2:end-1,2:end-1),[],1);
    f3_nodes  = reshape(nodes(1:end,end,1:end),[],1);
    f4_nodes = reshape(nodes(1,2:end-1,2:end-1),[],1);
    f5_nodes = reshape(nodes(1:end,2:end-1,1),[],1);
    f6_nodes = reshape(nodes(1:end,2:end-1,end),[],1);
    
    bound3D = sort([f1_nodes;f2_nodes;f3_nodes;f4_nodes;f5_nodes;f6_nodes]);
    
end
end

function [ref_nodes_x, ref_nodes_y,ref_nodes_z] = boundary_transform3D_squ_vec(coarse_nodes_x,coarse_nodes_y,coarse_nodes_z,fine_nodes_x,fine_nodes_y,fine_nodes_z)
% BOUNDARY_TRANSFORM3D_SQU_VEC  implements 3D inverse isoparametric transformation
% this maps coordinates of sub-elements onto the reference element
% [ref_nodes_x, ref_nodes_y, ref_nodes_z] = boundary_transform3D_squ_vec(coarse_nodes_x,coarse_nodes_y,coarse_nodes_z,fine_nodes_x,fine_nodes_y,fine_nodes_z)
% input 
%      coarse_nodes_x  : x coordinates of the nodes  of coarse grid
%      coarse_nodes_y  : y coordinates of the nodes  of coarse grid
%      coarse_nodes_z  : y coordinates of the nodes  of coarse grid
%      fine_nodes_x    : x coordinates of the nodes  of fine grid
%      fine_nodes_y    : y coordinates of the nodes  of fine grid
%      fine_nodes_z    : z coordinates of the nodes  of fine grid
%
% outpt
%      ref_nodes_x     : x coordinates of the nodes of the refernce elements
%      ref_nodes_y     : y coordinates of the nodes of the refernce elements
%      ref_nodes_z     : z coordinates of the nodes of the refernce elements

%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell

ref_nodes_x = (2*fine_nodes_x-coarse_nodes_x(:,1)-coarse_nodes_x(:,5))./(coarse_nodes_x(:,2)-coarse_nodes_x(:,5));
ref_nodes_y = (2*fine_nodes_y-coarse_nodes_y(:,1)-coarse_nodes_y(:,3))./(coarse_nodes_y(:,3)-coarse_nodes_y(:,1));
ref_nodes_z = (2*fine_nodes_z-coarse_nodes_z(:,1)-coarse_nodes_z(:,3))./(coarse_nodes_z(:,3)-coarse_nodes_z(:,1));
end
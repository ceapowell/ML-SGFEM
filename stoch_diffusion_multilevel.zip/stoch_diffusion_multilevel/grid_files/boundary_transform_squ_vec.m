function [ref_nodes_x, ref_nodes_y] = boundary_transform_squ_vec(coarse_nodes_x,coarse_nodes_y,fine_nodes_x,fine_nodes_y)
% BOUNDARY_TRANSFORM_SQU_VEC  implements inverse isoparametric transformation
% this maps coordinates of sub-elements onto the reference element
% [ref_nodes_x, ref_nodes_y] = boundary_transform_squ_vec(coarse_nodes_x,coarse_nodes_y,fine_nodes_x,fine_nodes_y)
% input 
%      coarse_nodes_x  : x coordinates of the nodes  of coarse grid
%      coarse_nodes_y  : y coordinates of the nodes  of coarse grid
%      fine_nodes_x    : x coordinates of the nodes  of fine grid
%      fine_nodes_y    : y coordinates of the nodes  of fine grid
%
% outpt
%      ref_nodes_x     : x coordinates of the nodes of the refernce elements
%      ref_nodes_y     : y coordinates of the nodes of the refernce elements
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell

ref_nodes_x = (2*fine_nodes_x-coarse_nodes_x(:,1)-coarse_nodes_x(:,2))./(coarse_nodes_x(:,2)-coarse_nodes_x(:,1));
ref_nodes_y = (2*fine_nodes_y-coarse_nodes_y(:,1)-coarse_nodes_y(:,3))./(coarse_nodes_y(:,3)-coarse_nodes_y(:,1));
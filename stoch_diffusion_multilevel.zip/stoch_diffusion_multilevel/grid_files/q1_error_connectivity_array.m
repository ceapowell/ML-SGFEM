function [mv,bound,mvrd,error_nodes,bound_reduced] = q1_error_connectivity_array(nel)
% Q1_ERROR_CONNECTIVITY_ARRAY generates full Q2 connectivity array excluding Q1 vertex nodes
% 5 nodes (element edge midpoitns and centroid) per element in 2D and 19
% nodes (face edge and centroid nodes) in 3D and reduced Q2 conectivity
% array of 7 nodes (face nodes and centroid)
% [mv,bound,mvrd] = q1_error_connectivity_array(nel)
% input
%      nel   : number of elements
%
% outpt
%      mv            : full Q2 macroelement mapping matrix
%      bound         : boundary vertex vector
%      mvrd          : reduced Q2 macroelement mapping matrix in 3D
%      error_nodes   : Q2 3D face and centoid nodes (reduced Q2) 
%      bound_reduced : boundary face nodes vector
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell
global dom_type;

mvrd = [];


if isequal(dom_type,'square')
    
    NODES = zeros(2*sqrt(nel)+1,2*sqrt(nel)+1);
    
    ind_end = 0;
    for i = 1:2*sqrt(nel)+1
        if rem(i,2) == 0
            keep = ind_end+1:ind_end+2*sqrt(nel)+1;
            ind_end = ind_end+2*sqrt(nel)+1;
            NODES(i,1:end) = keep;
        else
            keep = ind_end+1:ind_end+sqrt(nel);
            ind_end = ind_end+sqrt(nel);
            NODES(i,2:2:end) = keep;
        end
        
    end
    
    mv(:,1) = reshape(NODES(1:2:end-1,2:2:end)',nel,1);
    mv(:,2) = reshape(NODES(2:2:end,3:2:end)',nel,1);
    mv(:,3) = reshape(NODES(3:2:end,2:2:end)',nel,1);
    mv(:,4) = reshape(NODES(2:2:end,1:2:end-1)',nel,1);
    mv(:,5) = reshape(NODES(2:2:end,2:2:end)',nel,1);
    
    nodes_on_boundary = unique([NODES(1,:) NODES(end,:) NODES(:,1)' NODES(:,end)']);
    bound = nodes_on_boundary(2:end); % dont need node `zero'
    
elseif isequal(dom_type,'Lshape')
    
    NODES = zeros(2*sqrt(nel/3)+1,2*sqrt(nel/3));
    
    ind_end = 0;
    for i = 1:2*sqrt(nel/3)+1
        if rem(i,2) == 0
            keep = ind_end+1:ind_end+2*sqrt(nel/3);
            ind_end = ind_end+2*sqrt(nel/3);
            NODES(i,1:end) = keep;
        else
            keep = ind_end+1:ind_end+sqrt(nel/3);
            ind_end = ind_end+sqrt(nel/3);
            NODES(i,2:2:end) = keep;
        end
        
    end
    
    NODES = [NODES, zeros(size(NODES,1),1)];
    
    
    NODES2 = zeros(4*sqrt(nel/3)+1,2*sqrt(nel/3)+1);
    
    
    for i = 1:4*sqrt(nel/3)+1
        if rem(i,2) == 0
            keep = ind_end+1:ind_end+2*sqrt(nel/3)+1;
            ind_end = ind_end+2*sqrt(nel/3)+1;
            NODES2(i,1:end) = keep;
        else
            keep = ind_end+1:ind_end+sqrt(nel/3);
            ind_end = ind_end+sqrt(nel/3);
            NODES2(i,2:2:end) = keep;
        end
        
    end
    
    NODES(:,end) = NODES2(2*sqrt(nel/3)+1:end,1);
    %  NODES = [NODES;NODES2];
    
    mv(:,1) = reshape(NODES(1:2:end-1,2:2:end)',nel/3,1);
    mv(:,2) = reshape(NODES(2:2:end,3:2:end)',nel/3,1);
    mv(:,3) = reshape(NODES(3:2:end,2:2:end)',nel/3,1);
    mv(:,4) = reshape(NODES(2:2:end,1:2:end-1)',nel/3,1);
    mv(:,5) = reshape(NODES(2:2:end,2:2:end)',nel/3,1);
    
    mvv(:,1) = reshape(NODES2(1:2:end-1,2:2:end)',nel - nel/3,1);
    mvv(:,2) = reshape(NODES2(2:2:end,3:2:end)',nel - nel/3,1);
    mvv(:,3) = reshape(NODES2(3:2:end,2:2:end)',nel - nel/3,1);
    mvv(:,4) = reshape(NODES2(2:2:end,1:2:end-1)',nel - nel/3,1);
    mvv(:,5) = reshape(NODES2(2:2:end,2:2:end)',nel - nel/3,1);
    
    mv = [mv;mvv];
    
    nodes_on_boundary = unique([NODES(1,:) NODES2(:,1)'  NODES2(1,:) NODES2(:,end)' NODES(end,1:end-1) NODES2(end,:) NODES(:,1)']);
    bound = nodes_on_boundary(2:end);
    
else
    
    
    NODES = zeros(2*nthroot(nel,3)+1,2*nthroot(nel,3)+1,2*nthroot(nel,3)+1);
    ind_end = 0;
    for j =1:2*nthroot(nel,3)+1
        if mod(j,2) ==1
            for i = 1:2*nthroot(nel,3)+1
                if rem(i,2) == 0
                    keep = ind_end+1:ind_end+2*nthroot(nel,3)+1;
                    ind_end = ind_end+2*nthroot(nel,3)+1;
                    NODES(i,1:end,j) = keep;
                else
                    keep = ind_end+1:ind_end+nthroot(nel,3);
                    ind_end = ind_end+nthroot(nel,3);
                    NODES(i,2:2:end,j) = keep;
                end
            end
        else
            for i = 1:2*nthroot(nel,3)+1
                keep = ind_end+1:ind_end+2*nthroot(nel,3)+1;
                ind_end = ind_end+2*nthroot(nel,3)+1;
                NODES(i,1:end,j) = keep;
            end
        end
    end
    
    mvt(:,1) = reshape(NODES(1:2:end-1,2:2:end,1:2:end-1),nel,1);
    mvt(:,2) = reshape(NODES(2:2:end,3:2:end,1:2:end-1),nel,1);
    mvt(:,3) = reshape(NODES(3:2:end,2:2:end,1:2:end-1),nel,1);
    mvt(:,4) = reshape(NODES(2:2:end,1:2:end-1,1:2:end-1),nel,1);
    mvt(:,5) = reshape(NODES(2:2:end,2:2:end,1:2:end-1),nel,1);
    
    mvt(:,6)  = reshape(NODES(1:2:end-1,2:2:end,2:2:end),nel,1);
    mvt(:,7)  = reshape(NODES(1:2:end-1,3:2:end,2:2:end),nel,1);
    mvt(:,8)  = reshape(NODES(2:2:end,3:2:end,2:2:end),nel,1);
    mvt(:,9)  = reshape(NODES(3:2:end,3:2:end,2:2:end),nel,1);
    mvt(:,10) = reshape(NODES(3:2:end,2:2:end,2:2:end),nel,1);
    mvt(:,11) = reshape(NODES(3:2:end,1:2:end-1,2:2:end),nel,1);
    mvt(:,12) = reshape(NODES(2:2:end,1:2:end-1,2:2:end),nel,1);
    mvt(:,13) = reshape(NODES(1:2:end-1,1:2:end-1,2:2:end),nel,1);
    mvt(:,14) = reshape(NODES(2:2:end,2:2:end,2:2:end),nel,1);
    
    
    mvt(:,15) = reshape(NODES(1:2:end-1,2:2:end,3:2:end),nel,1);
    mvt(:,16) = reshape(NODES(2:2:end,3:2:end,3:2:end),nel,1);
    mvt(:,17) = reshape(NODES(3:2:end,2:2:end,3:2:end),nel,1);
    mvt(:,18) = reshape(NODES(2:2:end,1:2:end-1,3:2:end),nel,1);
    mvt(:,19) = reshape(NODES(2:2:end,2:2:end,3:2:end),nel,1);
    
    [indx,pos] = sort(mvt(:,1));
    
    mv = [indx mvt(pos,2:end)];
    
    mvrd(:,1) = mv(:,6);
    mvrd(:,2) = mv(:,8);
    mvrd(:,3) = mv(:,10);
    mvrd(:,4) = mv(:,12);
    mvrd(:,5) = mv(:,5);
    mvrd(:,6) = mv(:,19);
    mvrd(:,7) = mv(:,14);
    error_nodes = [14 16 18 20 13 27 22];
    
    f1_nodes = reshape(NODES(1,2:end-1,2:end-1),[],1);
    f2_nodes = reshape(NODES(1:end,end,1:end),[],1);
    f3_nodes = reshape(NODES(end,2:end-1,2:end-1),[],1);
    f4_nodes = reshape(NODES(1:end,1,1:end),[],1);
    f5_nodes = reshape(NODES(1:end,2:end-1,1),[],1);
    f6_nodes = reshape(NODES(1:end,2:end-1,end),[],1);
    
    
    f1_nodes_reduced = reshape(NODES(1,2:2:end-1,2:2:end-1),[],1);
    f2_nodes_reduced = reshape(NODES(2:2:end-1,end,2:2:end-1),[],1);
    f3_nodes_reduced = reshape(NODES(end,2:2:end-1,2:2:end-1),[],1);
    f4_nodes_reduced = reshape(NODES(2:2:end,1,2:2:end-1),[],1);
    f5_nodes_reduced = reshape(NODES(2:2:end,2:2:end-1,1),[],1);
    f6_nodes_reduced = reshape(NODES(2:2:end,2:2:end-1,end),[],1);
    
    bound = unique(sort([f1_nodes;f2_nodes;f3_nodes;f4_nodes;f5_nodes;f6_nodes]));
    bound = bound(2:end);
    bound_reduced = unique(sort([f1_nodes_reduced;f2_nodes_reduced;f3_nodes_reduced;f4_nodes_reduced;f5_nodes_reduced;f6_nodes_reduced]));
    
    
    
end


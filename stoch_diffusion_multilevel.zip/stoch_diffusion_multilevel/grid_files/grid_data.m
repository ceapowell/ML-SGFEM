function [ev,mv,xy,bound] = grid_data(nc)
% GRID_DATA generates square or el-shape domain of size nc
%[ev,mv,xy,bound] = grid_data(nc)
% input
%      nc           : grid level
% outpt
%      ev           : element matrix
%      mv           : Macroelement matrix
%      xy           : vertex coordinate vector
%      bound        : boundary vertex vector
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell

global dom_type TP

if isequal(dom_type,'square')
    
    steps = 2^nc;                                              % number of elements in 1D
    
    
    nvtx = (steps + 1)^2;                                      % total number of nodes
    
    if TP == 1
        x = linspace(-1,1,steps+1); y = x;                     % x and y coordinates in 1D TP2
    else
        x = linspace(0,1,steps+1); y = x;                      % x and y coordinates in 1D TP5
    end
    
    [X,Y] = meshgrid(x,y);                                     % generate 2D mesh
    xx = reshape(X',nvtx,1); yy = reshape(Y',nvtx,1);
    xy = [xx(:),yy(:)];                                        % store x and y coordinates of nodes (of which there are nvtx of them)
    nodes = reshape(1:nvtx,sqrt(nvtx),sqrt(nvtx))';            % matrix reflecting node ordering
    nel = steps^2;
    ev = zeros(nel,4);                                         % initialise connectivity array
    
    
    ev(:,1) = reshape(nodes(1:end-1,1:end-1)',[],1);
    ev(:,2) = reshape(nodes(1:end-1,2:end)',[],1);
    ev(:,3) = reshape(nodes(2:end,2:end)',[],1);
    ev(:,4) = reshape(nodes(2:end,1:end-1)',[],1);
    
    
    mv(:,1) = reshape(nodes(1:2:end-1,1:2:end-1)',[],1);
    mv(:,2) = reshape(nodes(1:2:end-1,3:2:end)',[],1);
    mv(:,3) = reshape(nodes(3:2:end,3:2:end)',[],1);
    mv(:,4) = reshape(nodes(3:2:end,1:2:end-1)',[],1);
    mv(:,5) = reshape(nodes(1:2:end-1,2:2:end-1)',[],1);
    mv(:,6) = reshape(nodes(2:2:end-1,3:2:end)',[],1);
    mv(:,7) = reshape(nodes(3:2:end,2:2:end)',[],1);
    mv(:,8) = reshape(nodes(2:2:end-1,1:2:end-1)',[],1);
    mv(:,9) = reshape(nodes(2:2:end-1,2:2:end-1)',[],1);
    
    
    bound = [nodes(1,1); nodes(1,2:end-1)'; nodes(1,end); nodes(2:end-1,end); nodes(end,end); nodes(end,2:end-1)'; nodes(end,1); nodes(2:end-1,1)];
    
    
else
    
    if TP == 5 || TP == 6
        x_min = -1;
        x_max = 1;
        y_min = -1;
        y_max = 1;
        x_mean = (x_min+x_max)/2;
        y_mean = (y_min+y_max)/2;
    end
    steps = (2^nc)/2; % number of elements in 1D
    
    
    xul = linspace(x_min,x_mean,steps+1);
    yul = linspace(y_mean,y_max,steps+1);
    
    xul = xul(1:end-1);
    %    yul = yul(1:end-1);
    
    nvtx1 = (steps)^2+2^(nc-1); % total number of nodes
    
    [X,Y] = meshgrid(xul,yul); % generate 2D mesh
    
    xx = reshape(X',nvtx1,1); yy = reshape(Y',nvtx1,1);
    
    xyul = [xx(:),yy(:)]; % store x and y coordinates of nodes (of which there are nvtx of them)
    
    nodes0 = reshape(1:nvtx1, nvtx1/size(X,1),[])'; % matrix reflecting node ordering
    
    nel = steps^2 - 2^(nc-1);
    ev0 = zeros(nel,4);
    
    
    ev0(:,1) = reshape(nodes0(1:end-1,1:end-1)',[],1);
    ev0(:,2) = reshape(nodes0(1:end-1,2:end)',[],1);
    ev0(:,3) = reshape(nodes0(2:end,2:end)',[],1);
    ev0(:,4) = reshape(nodes0(2:end,1:end-1)',[],1);
    
    
    
    steps2 = (2^nc);
    xdr = linspace(x_mean,x_max,steps+1);
    ydr = linspace(y_min,y_max,steps2+1);
    
    [X,Y] = meshgrid(xdr,ydr); % generate 2D mesh
    
    nvtx = size(X,1)*size(X,2);
    
    xx = reshape(X',nvtx,1); yy = reshape(Y',nvtx,1);
    
    xydr = [xx(:),yy(:)]; % store x and y coordinates of nodes (of which there are nvtx of them)
    
    start = nvtx1+1;
    last = nvtx+nvtx1;
    nodes1 = reshape(start:last ,size(X,2),[])'; % matrix reflecting node ordering
    
    
    nel = 2*(steps)^2;
    ev1 = zeros(nel,4);
    
    
    ev1(:,1) = reshape(nodes1(1:end-1,1:end-1)',[],1);
    ev1(:,2) = reshape(nodes1(1:end-1,2:end)',[],1);
    ev1(:,3) = reshape(nodes1(2:end,2:end)',[],1);
    ev1(:,4) = reshape(nodes1(2:end,1:end-1)',[],1);
    
    evv = zeros((steps)^2,4);
    j=1;
    
    count =steps^2+1;
    
    for i =1:size(evv,1)
        if mod(i,2^(nc-1))~=0
            evv(i,:) = ev0(j,:);
            j=j+1;
        end
        
        if mod(i,2^(nc-1)) == 0
            evv(i,1) = ev0(j-1,2);
            evv(i,2) = ev1(count,1);
            evv(i,3) = ev1(count,4);
            evv(i,4) = ev0(j-1,3);
            count =count +steps;
        end
    end
    
    ev = [evv;ev1];
    xy = [xyul;xydr];
    n=2^nc; np=n/2; nq=n/4;
    
    %
    v  = 1:2:nq+nq;
    nn = length(v);
    xn = 1:nq*nq;
    kx = v;
    ky = ones(nn,nn).*v;
    
    mel=xn;
    mref=np*(ky-1)+kx';
    nvv(:,1) = mref(:);        nvv(:,2) = mref(:)+2;  nvv(:,3) = mref(:)+2*np+2;
    nvv(:,4) = mref(:)+2*np;   nvv(:,5) = mref(:)+1;  nvv(:,6) = mref(:)+np+2;
    nvv(:,7) = mref(:)+2*np+1; nvv(:,8)=  mref(:)+np; nvv(:,9)=  mref(:)+np+1;
    mv(mel,1:9)=nvv(:,1:9);
    
    % correction along the internal boundary
    mref=2*np*(np+1)+1;
    for mel=nq:nq:nq*nq
        nvv=mv(mel,:);
        nvv(2) = mref;
        nvv(3) = mref+2*np+2;
        nvv(6) = mref+np+1;
        mv(mel,1:9)=nvv(1:9);
        mref=mref+2*np+2;
    end
    
    clear nvv
    v1  = 1:2:np+np;
    v2  = 1:2:nq+nq;
    nn1 = length(v1);
    nn2 = length(v2);
    xn = 1:np*nq;
    kx = v2;
    ky = ones(nn2,nn1).*v1;
    mel = xn+length(mv(:,1));
    
    mref = (np+1)*(ky-1)+kx' + np*(np+1);
    nvv(:,1) = mref(:);        nvv(:,2) = mref(:)+2;         nvv(:,3) = mref(:)+2*np+4;
    nvv(:,4) = mref(:)+2*np+2; nvv(:,5) = mref(:)+1;         nvv(:,6) = mref(:)+np+3;
    nvv(:,7) = mref(:)+2*np+3; nvv(:,8)=  mref(:)+np+1;      nvv(:,9)=  mref(:)+np+2;
    mv(mel,1:9)=nvv(:,1:9);
    
    %
    %% compute boundary vertices
    % six boundary edges
    k1=find( xy(:,1) <x_mean  & xy(:,2)==y_mean ); k2=find( xy(:,1)==x_mean & xy(:,2)<=y_mean );
    k3=find( xy(:,1) >x_mean  & xy(:,2)== y_min);  k4=find( xy(:,1)==x_max  & xy(:,2)<y_max   & xy(:,2) >y_min);
    k5=find( xy(:,2)==x_max );                     k6=find( xy(:,1)==x_min  & xy(:,2)<y_max  & xy(:,2) >y_mean );
    bound=sort([k1;k2;k3;k4;k5;k6]);
  
end
end





function el_save = fine_el_retrieval(nel_q,nel_r)
% FINE_EL_RETRIEVAL returns the numbering of the fine elements which sit in each coarse element
% el_save = fine_el_retrieval(nel_q,nel_r)
% input
%       nel_q,nel_r  : number of elements in the coarce and the fine grids
% outpt
%       el_save      : numbering of the fine elements in the coarse mesh
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell


global dom_type
n_subel = nel_r/nel_q;

el_save = zeros(nel_q,n_subel);

if isequal(dom_type,'square')
    fine_els = reshape(1:nel_r,sqrt(nel_r),sqrt(nel_r));
    fine_save = mat2cell(fine_els,sqrt(n_subel)*ones(1,sqrt(nel_q)),sqrt(n_subel)*ones(1,sqrt(nel_q)));
    fine_save = reshape(fine_save,nel_q,1);
    
    for i = 1:nel_q
        %     el_save(i,:) = sort(fine_save{i}(:));
        el_save(i,:) = fine_save{i}(:);
    end
    
elseif isequal(dom_type,'Lshape')
    fine_els = reshape(1:nel_r,sqrt(nel_r/3),[]);
    fine_save = mat2cell(fine_els,sqrt(n_subel)*ones(1,sqrt(nel_q/3)),sqrt(n_subel)*ones(1,3*sqrt(nel_q/3)));
    fine_save = reshape(fine_save,nel_q,1);
    for i = 1:nel_q
        el_save(i,:) = fine_save{i}(:);
    end
else
    fine_els = reshape(1:nel_r,nthroot(nel_r,3),nthroot(nel_r,3),nthroot(nel_r,3));
    fine_save = mat2cell(fine_els,nthroot(n_subel,3)*ones(1,nthroot(nel_q,3)),nthroot(n_subel,3)*ones(1,nthroot(nel_q,3)),nthroot(n_subel,3)*ones(1,nthroot(nel_q,3)));
    fine_save = reshape(fine_save,nel_q,1);
    
    for i = 1:nel_q
        el_save(i,:) = fine_save{i}(:);
    end
    
end

end







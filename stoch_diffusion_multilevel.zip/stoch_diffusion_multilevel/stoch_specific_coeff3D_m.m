function a = stoch_specific_coeff3D_m(x,y,z,nel,norv,KL_DATA,n)
%STOCH_SPECIFIC_COEFF3D_M   Analytic KL stochastic diffusion 3D coefficient
%   a = stoch_specific_coeff3D_m(x,y,z,nel,norv,KL_DATA,n)
%   input
%          x       :  x coordinate vector
%          y       :  y coordinate vector
%          z       :  z coordinate vector
%          nel     :  number of elements
%          norv    :  number of random variables
%          KL_DATA :  data related to KL-expansion
%          n       :  parameter number
%   output
%          a       : Analytic KL stochastic 3D diffusion coefficient
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022  A. J. Crowder, G. Papanikos, C.E. Powell

% initialisation
a=zeros(nel,1);

% get standard deviation
sigma = KL_DATA.input(4);
if n == 0
    a(:,1)=ones(nel,1);
else
    lambda = KL_DATA.ev3d(n);
    nx = KL_DATA.ev3d_ind(n,1);   ny = KL_DATA.ev3d_ind(n,2);  nz = KL_DATA.ev3d_ind(n,3);
    omega_x = KL_DATA.ev_x(nx,2); alpha_x = KL_DATA.ev_x(nx,3);
    omega_y = KL_DATA.ev_y(ny,2); alpha_y = KL_DATA.ev_y(ny,3);
    omega_z = KL_DATA.ev_z(nz,2); alpha_z = KL_DATA.ev_z(nz,3);
    
    type_x = KL_DATA.ef_indic(nx); type_y = KL_DATA.ef_indic(ny); type_z = KL_DATA.ef_indic(nz);
    %
    fx = alpha_x * (((1 + type_x)/2) * cos(x*omega_x) + ((1 - type_x)/2) * sin(x*omega_x));
    fy = alpha_y * (((1 + type_y)/2) * cos(y*omega_y) + ((1 - type_y)/2) * sin(y*omega_y));
    fz = alpha_z * (((1 + type_z)/2) * cos(z*omega_z) + ((1 - type_z)/2) * sin(z*omega_z));
    %
    a(:) = sigma * sqrt(3.0e0) * sqrt(lambda) * fx .* fy.* fz;
end
return
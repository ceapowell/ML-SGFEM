
% SETPATH sets search path
% IFISS scriptfile: DJS; 2 January 2011.
% Copyright (c) 2009 D.J. Silvester, H.C. Elman, A. Ramage 

gohome, 
warning('off', 'all')
addpath(genpath(pwd),'-end')


function [enrich_loc,enrich_type] = enrichment_indices(version,nc,ncq,EY1,EY2,Ndof_old)
% ENRICHMENT_INDICES construct suitable sets JP, JQ and determines how to enrich the current 
% SGFEM space
%[enrich_loc,enrich_type] = enrichment_indices(version,nc,ncq,EY1,EY2,Ndof_old)
% input 
%      version     :   2 versions of enrichment 
%      nc          :   FEM levels for each multi-index
%      ncq         :   position of NCQ in nc
%      EY1         :   set of spatial error estimate
%      EY2         :   set of parametric error estimare
%      Ndof_old    :   number of degrees of freedom for each level
%
% outpt
%      enrich_loc  :  Indices locations with the highest error 
%      enrich_type :  type of enrichment:  0 spatial, 1 parametric 
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022  G. Papanikos, A.J. Crowder, C.E. Powell
global dom_type

if isequal(dom_type,'square')
   NY1 = ((2.^(nc+1)) - 1).^2 - Ndof_old;
elseif isequal(dom_type,'Lshape')
   NY1 = ((2.^(nc+1)) - 1).^2-2.^((2.*(nc+1)-2)) - Ndof_old; 
else
  NY1 = ((2.^(nc+1)) - 1).^3 - Ndof_old;
end
 NY2 = Ndof_old(ncq);


RY1 = EY1./NY1; RY2 = EY2/NY2;    
delta_Y1 = max(RY1); delta_Y2 = max(RY2);

if delta_Y1 > delta_Y2
    Y2_loc = find(RY2 == delta_Y2);
    if version == 1;
        Y1_loc = find(RY1  > delta_Y2); 
    else
        [~,J] = sort(RY1,'descend'); 
        EY1_sorted = EY1(J);
        NY1_sorted = NY1(J);
        RY1_cummulative = cumsum(EY1_sorted)./cumsum(NY1_sorted);
        Y1_loc = J(1:length(find(RY1_cummulative>delta_Y2)));
    end
else
    Y1_loc = find(RY1 == delta_Y1);
    if version == 1
        Y2_loc = find(RY2  > delta_Y1);
    else
        [~,J] = sort(RY2,'descend');
        EY2_sorted = EY2(J);
        NY2_vec = NY2*ones(1,length(EY2));        
        RY2_cummulative = cumsum(EY2_sorted)./cumsum(NY2_vec);
        Y2_loc = J( 1:length(find(RY2_cummulative>delta_Y1)));
    end
end

RW1 = sum(EY1(Y1_loc))/sum(NY1(Y1_loc)); RW2 = sum(EY2(Y2_loc))/(NY2*length(Y2_loc));

if RW1 > RW2
    enrich_type = 1; enrich_loc = Y1_loc;
else
    enrich_type = 0; enrich_loc = Y2_loc;
end
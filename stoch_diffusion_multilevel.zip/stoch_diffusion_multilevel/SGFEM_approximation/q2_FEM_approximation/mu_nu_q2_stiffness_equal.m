function [A,f] = mu_nu_q2_stiffness_equal(ncq,m,nc,norv,KL_DATA)
% MU_NU_Q2_STIFFNESS_EQUAL stochastic coefficient stiffness matrix generation for
% same levels using biquadratic (Q2) basis functions
%[A,f] = mu_nu_stiffness_equal(ncq,ncr,m,nc,norv,KL_DATA)
% input
%      ncq     : FEM level for the multi-index q
%      m       : index of parameter under consideration
%      nc      : FEM levels for each multi-index
%      norv    : total number of parameters
%      KL_DATA : data from KL expansion, needed for stiffness matrices
%
% outpt
%          A   : stiffness matrix
%          f   : rhs vector
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell


[~,mv,xy,bound] = grid_data(ncq); % compute mesh data for required level

x = xy(:,1); y = xy(:,2); nvtx = length(x); nel = length(mv(:,1)); % organise required data

f = zeros(nvtx,1);

ngpt = 10; [oneg,onew] = gausspoints_oned(ngpt); [s,t,wt] = gausspoints_twod(oneg,onew); % setup quadrature for stiffness matrices
nngpt = ngpt^2;

A_local = zeros(nel,9,9); % initialise local LHS
f_local = zeros(nel,9);   % initialise local RHS



xl_v = x(mv(:,1:4));
yl_v = y(mv(:,1:4));

for igpt = 1:nngpt
    
    sigpt = s(igpt); tigpt = t(igpt); wght = wt(igpt);
    
    [jac,invjac,~,~,~]  = deriv(sigpt,tigpt,xl_v,yl_v);
    [psi,dpsidx,dpsidy] = qderiv(sigpt,tigpt,xl_v,yl_v);
    
    coeff = stoch_gauss_coeff_m(sigpt,tigpt,xl_v,yl_v,norv,KL_DATA,m);
    rhs = stoch_gauss_source(sigpt,tigpt,xl_v,yl_v,0); % the RHS has no parameter dependence so we can set norv = 0 for dramatic speedup
    
    f_local = f_local + wght*rhs(:).*psi.*jac(:);
    A_local = A_local + wght*coeff(:).*(dpsidx.*permute(dpsidx,[1 3 2]) + dpsidy.*permute(dpsidy,[1,3,2])).*invjac(:);
    
end

% construct global matrix concatenating local ones
for krow = 1:9
    nrow = mv(:,krow);
    f(nrow,1) = f(nrow,1) + f_local(:,krow);
end

[Nrows,Ncols] = size(mv);
ncol = repmat(reshape(mv,Nrows*Ncols,1),9,1);

nrow = repmat(mv,Ncols,1);

A = sparse(nrow(:),ncol,A_local(:),nvtx,nvtx);

A(bound,:) = []; A(:,bound) = []; f(bound) = []; % apply zero dirichlet BCs
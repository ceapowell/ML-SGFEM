function [A,f] = mu_nu_q2_stiffness(ncq,ncr,m,nc,norv,KL_DATA)
% MU_NU_Q2_STIFFNESS  stochastic coefficient stiffness matrix generation for
% same or different levels using biquandratic (Q2) basis functions
%[A,f] = mu_nu_q2_stiffness(ncq,ncr,m,nc,norv,KL_DATA)
% input 
%      ncq     : FEM level for the multi-index q
%      ncr     : FEM level for the multi-index r
%      m       : index of parameter under consideration
%      nc      : FEM levels for each multi-index
%      norv    : total number of parameters
%      KL_DATA : data from KL expansion, needed for stiffness matrices
%
% outpt
%          A   : stiffness matrix
%          f   : rhs vector
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022  G. Papanikos, A. J. Crowder, C.E. Powell

% construct deterministic matrices
if ncq == ncr % mu and nu are on the same FEM level (default SGFEM)
    [A,f] = mu_nu_q2_stiffness_equal(ncq,m,nc,norv,KL_DATA);    
else
    if ncq > ncr % swap levels for convenience. can be done since problem is symmetric
        [A] = mu_nu_q2_stiffness_nonequal(ncr,ncq,m,nc,norv,KL_DATA); 
         A = A';
    else
        [A] = mu_nu_q2_stiffness_nonequal(ncq,ncr,m,nc,norv,KL_DATA);
    end
    
end
function [A] = mu_nu_q2_stiffness_nonequal(ncq,ncr,m,nc,norv,KL_DATA)
% MU_NU_Q2_STIFFNESS_NONEQUAL stochastic coefficient stiffness matrix generation for
% different levels using biquadratic (Q2) basis functions
%[A] = mu_nu_q2_stiffness_nonequal(ncq,ncr,m,nc,norv,KL_DATA)
% input 
%      ncq     : FEM level for for the multi-index q
%      ncr     : FEM level for for the multi-index r
%      m       : index of parameter under consideration
%      nc      : FEM levels for each multi-index
%      norv    : total number of parameters
%      KL_DATA : data from KL expansion, needed for stiffness matrices
%
% outpt
%          A   : stiffness matrix
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos,  A. J. Crowder, C.E. Powell

% ncq = nc(q);
% ncr = nc(r);

[~,mv_q,xy_q,bound_q] = grid_data(ncq); [~,mv_r,xy_r,bound_r] = grid_data(ncr);

nvtx_q = size(xy_q,1); nvtx_r = size(xy_r,1); % number of coarse and fine DOF

nel_q = length(mv_q(:,1)); % number of coarse elements
nel_r = length(mv_r(:,1)); % number of fine elements

x_q = xy_q(:,1); y_q = xy_q(:,2); % coarse data
xl_q = x_q(mv_q(:,1:4)); yl_q = y_q(mv_q(:,1:4));

x_r = xy_r(:,1); y_r = xy_r(:,2); % fine data
xl_r = x_r(mv_r(:,1:4)); yl_r = y_r(mv_r(:,1:4));

lev_diff = abs(ncq-ncr);


n_subel = (2^lev_diff)^2; % determine how many fine elements per coarse element - minimum is four if levels are not equal

el_save = fine_el_retrieval(nel_q,nel_r); % this is the numbering of the fine elements which sit in each coarse element

ngpt = 7; [oneg,onew] = gausspoints_oned(ngpt); [s,t,wt] = gausspoints_twod(oneg,onew); nngpt=ngpt^2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% new approach
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

coarse_x_vec = repmat(xl_q,n_subel,1);
coarse_y_vec = repmat(yl_q,n_subel,1);

fine_x = xl_r(el_save,:);
fine_y = yl_r(el_save,:);

[ref_nodes_x, ref_nodes_y] = boundary_transform_squ_vec(coarse_x_vec,coarse_y_vec,fine_x,fine_y);

phi_st = vshape(s',t')';
s_trans = ref_nodes_x*phi_st; t_trans = ref_nodes_y*phi_st;

a_small = zeros(nel_r,9,9);

for igpt = 1:nngpt
    
    
    [invjac_c,~,dpsidx_c,dpsidy_c] = vqderiv(s_trans(:,igpt),t_trans(:,igpt),coarse_x_vec,coarse_y_vec);
    sigpt = s(igpt); tigpt = t(igpt); wght = wt(igpt);
    
    [~,dpsidx_f,dpsidy_f] = qderiv(sigpt,tigpt,fine_x,fine_y);
    coeff = stoch_gauss_coeff_m(sigpt,tigpt,fine_x,fine_y,norv,KL_DATA,m);
    
    for j = 1:9
        for i = 1:9
            a_small(:,j,i) = a_small(:,j,i) + wght(1)*coeff(:).*(dpsidx_c(:,i).*dpsidx_f(:,j)+dpsidy_c(:,i).*dpsidy_f(:,j)).*invjac_c(:);
        end
    end
    
end

row_index = repmat(repmat(mv_q,n_subel,1),9,1);
col_index = repmat(mv_r(el_save,:),1,9);

A = sparse(row_index(:),col_index(:),a_small(:),nvtx_q,nvtx_r);

A(bound_q,:) = [];
A(:,bound_r) = [];


function [U_gal,U] = u_gal_reconstruct(u,nc)
% U_GAL_RECONSTRUCT add zeros to the SGFEM solution from boundary nodes
% and split it into P pieces
%[U_gal,U] = u_gal_reconstruct(u,nc)
% input
%      u           : SFGEM Solution
%      nc          : FEM levels for each multi-index
%
% outpt
%      U_gal         :  cell array with SGFEM solution for each level with zero boundary nodes
%      U             :  cell array with SGFEM solution for each level
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022  A.J. Crowder, G. Papanikos, C.E. Powell
global  dom_type
if  isequal(dom_type,'square')
    N = (2.^nc-1).^2; % number of internal (solution) nodes per level
elseif isequal(dom_type,'Lshape')
    N = (2.^nc-1).^2 -2.^(2.*nc-2);
else
    N = (2.^nc-1).^3;
end
U = mat2cell(u,N,1); % split sol into vectors associated with each level

P = length(nc);

U_gal = cell(1,P);

for p = 1:P
    if  isequal(dom_type,'square')|| isequal(dom_type,'Lshape')
        [~,~,xy,bound] = grid_data(nc(p));
        p_sol_len = size(xy,1); UU = zeros(p_sol_len,1);
    else
        [~,~,xyz,bound] = grid_data3D(nc(p));
        p_sol_len = size(xyz,1); UU = zeros(p_sol_len,1);
    end
    
    non_bound = setdiff(1:p_sol_len,bound);
    UU(non_bound) = U{p};
    U_gal{p} = UU;
end

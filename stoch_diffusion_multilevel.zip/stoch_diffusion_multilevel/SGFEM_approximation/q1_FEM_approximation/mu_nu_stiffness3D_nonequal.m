function [A] = mu_nu_stiffness3D_nonequal(ncq,ncr,m,nc,norv,KL_DATA)
% MU_NU_STIFFNESS3D_NONEQUAL stochastic coefficient stifness matrix generation for
% differenct mesh levels using trilinear basis functions (Q1)
%[A] = mu_nu_stiffness3D_nonequal(ncq,ncr,m,nc,norv,KL_DATA)
% input
%      ncq     : FEM level for the multi-index q
%      ncr     : FEM level for the multi-index r
%      m       : index of parameter under consideration
%      nc      : FEM levels for each multi-index
%      norv    : total number of parameters
%      KL_DATA : data from KL expansion, needed for stiffness matrices
%
% outpt
%          A   : stiffness matrix
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell

% ncq = nc(q);
% ncr = nc(r);

[ev_q,~,xyz_q,bound3D_q] = grid_data3D(ncq); [ev_r,~,xyz_r,bound_r] = grid_data3D(ncr);

nvtx_q = size(xyz_q,1); nvtx_r = size(xyz_r,1); % number of coarse and fine DOF

nel_q = length(ev_q(:,1)); % number of coarse elements
nel_r = length(ev_r(:,1)); % number of fine elements

x_q = xyz_q(:,1); y_q = xyz_q(:,2); z_q = xyz_q(:,3); % coarse data
xl_q = x_q(ev_q); yl_q = y_q(ev_q); zl_q = z_q(ev_q);

x_r = xyz_r(:,1); y_r = xyz_r(:,2); z_r = xyz_r(:,3); % fine data
xl_r = x_r(ev_r); yl_r = y_r(ev_r); zl_r = z_r(ev_r);

lev_diff = abs(ncq-ncr);


n_subel = (2^lev_diff)^3; % determine how many fine elements per coarse element - minimum is four if levels are not equal

el_save = fine_el_retrieval(nel_q,nel_r); % this is the numbering of the fine elements which sit in each coarse element

ngpt=3; [oneg,onew] = gausspoints_oned(ngpt); [s,t,l,wt] = gausspoints_threed(oneg,onew);  nngpt=ngpt^3;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% new approach
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

coarse_x_vec = repmat(xl_q,n_subel,1);
coarse_y_vec = repmat(yl_q,n_subel,1);
coarse_z_vec = repmat(zl_q,n_subel,1);

fine_x = xl_r(el_save,:);
fine_y = yl_r(el_save,:);
fine_z = zl_r(el_save,:);

[ref_nodes_x, ref_nodes_y,ref_nodes_z] = boundary_transform3D_squ_vec(coarse_x_vec,coarse_y_vec,coarse_z_vec,fine_x,fine_y,fine_z);

phi_st = vshape3D(s,t,l)';
s_trans = ref_nodes_x*phi_st'; t_trans = ref_nodes_y*phi_st'; l_trans = ref_nodes_z*phi_st';

a_small = zeros(nel_r,8,8);

for igpt = 1:nngpt
    
    [~,invjac_c,~,dphidx_c,dphidy_c,dphidz_c] = vderiv3D(s_trans(:,igpt),t_trans(:,igpt),l_trans(:,igpt),coarse_x_vec,coarse_y_vec,coarse_z_vec);
    
    sigpt = s(igpt); tigpt = t(igpt); ligpt = l(igpt); wght = wt(igpt);
    
    [~,~,~,dphidx_f,dphidy_f,dphidz_f] = deriv3D(sigpt,tigpt,ligpt,fine_x,fine_y,fine_z);
    coeff = stoch_gauss_coeff3D_m(sigpt,tigpt,ligpt,fine_x,fine_y,fine_z,norv,KL_DATA,m);
    
    for j = 1:8
        for i = 1:8
            a_small(:,j,i) = a_small(:,j,i) + wght(1)*coeff(:).*(dphidx_c(:,i).*dphidx_f(:,j)+dphidy_c(:,i).*dphidy_f(:,j)+dphidz_c(:,i).*dphidz_f(:,j)).*invjac_c(:);
        end
    end
    
end

row_index = repmat(repmat(ev_q,n_subel,1),8,1);
col_index = repmat(ev_r(el_save,:),1,8);

A = sparse(row_index(:),col_index(:),a_small(:),nvtx_q,nvtx_r);

A(bound3D_q,:) = [];
A(:,bound_r) = [];
end
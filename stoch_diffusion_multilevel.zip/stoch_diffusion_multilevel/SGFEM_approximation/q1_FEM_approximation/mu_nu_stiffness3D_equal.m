function [A,f] = mu_nu_stiffness3D_equal(ncq,m,nc,norv,KL_DATA)
% MU_NU_STIFFNESS3D_EQUAL stochastic coefficient stiffness matrix generation for
% same mesh levels using trilinear basis functions (Q1) 
%[A,f] = mu_nu_stiffness3D_equal(ncq,m,nc,norv,KL_DATA)
% input
%      ncq     : FEM level for the multi-index q
%      m       : index of parameter under consideration
%      nc      : FEM levels for each multi-index
%      norv    : total number of parameters
%      KL_DATA : data from KL expansion, needed for stiffness matrices
%
% outpt
%          A   : stiffness matrix
%          f   : rhs vector
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos,A.J. Crowder, C.E. Powell



[ev,~,xyz,bound3D] = grid_data3D(ncq); % compute mesh data for required level

x = xyz(:,1); y = xyz(:,2); z = xyz(:,3); nvtx = length(x); nel = length(ev(:,1)); % organise required data

f = zeros(nvtx,1);

ngpt = 3; [oneg,onew] = gausspoints_oned(ngpt); 
[s,t,l,wt] = gausspoints_threed(oneg,onew);
nngpt = ngpt^3;

A_local = zeros(nel,8,8); % initialise local LHS
f_local = zeros(nel,8); % initialise local RHS

xl_v = x(ev); yl_v = y(ev); zl_v = z(ev);

for igpt = 1:nngpt
    
    sigpt = s(igpt); tigpt = t(igpt); ligpt = l(igpt); wght = wt(igpt);
    
    [jac,invjac,phi,dphidx,dphidy,dphidz] = deriv3D(sigpt,tigpt,ligpt,xl_v,yl_v,zl_v);
    
    coeff = stoch_gauss_coeff3D_m(sigpt,tigpt,ligpt,xl_v,yl_v,zl_v,norv,KL_DATA,m);
    rhs = stoch_gauss_source3D(sigpt,tigpt,ligpt,xl_v,yl_v,zl_v,0); % the RHS has no parameter dependence so we can set norv = 0 for dramatic speedup
    
    f_local = f_local + wght*rhs(:).*phi.*jac(:);
    A_local = A_local + wght*coeff(:).*( dphidx.*permute(dphidx,[1 3 2]) + dphidy.*permute(dphidy,[1,3,2]) + dphidz.*permute(dphidz,[1,3,2]) ).*invjac(:);
    
end

% construct global matrix concatenating local ones
for krow = 1:8
    nrow = ev(:,krow);
    f(nrow,1) = f(nrow,1) + f_local(:,krow);
end

[Nrows,Ncols] = size(ev);
ncol = repmat(reshape(ev,Nrows*Ncols,1),8,1);

nrow = repmat(ev,Ncols,1);

A = sparse(nrow(:),ncol,A_local(:),nvtx,nvtx);

A(bound3D,:) = []; A(:,bound3D) = []; f(bound3D) = []; % apply zero dirichlet BCs
end
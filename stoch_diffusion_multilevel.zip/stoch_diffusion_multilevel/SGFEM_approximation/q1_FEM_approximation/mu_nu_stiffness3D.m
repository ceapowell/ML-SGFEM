function [A,f] = mu_nu_stiffness3D(ncq,ncr,m,nc,norv,KL_DATA)
% MU_NU_STIFFNESS3D  stochastic coefficient stiffness matrix generation for
% same or different levels with trilinear (Q1) basis functions
%[A,f] = mu_nu_stiffness3D(ncq,ncr,m,nc,norv,KL_DATA)
% input 
%      ncq     : FEM level for the multi-index q
%      ncr     : FEM level for the multi-index r
%      m       : index of parameter under consideration
%      nc      : FEM levels for each multi-index
%      norv    : total number of parameters
%      KL_DATA : data from KL expansion, needed for stiffness matrices
%
% outpt
%          A   : stiffness matrix
%          f   : rhs vector
%
% Multilevel SGFEM function: GP; 01 December 2021.
% Copyright (c) 2022  G. Papanikos, A.J. Crowder, C.E. Powell


% ncq = nc(q);
% ncr = nc(r);


% construct deterministic matrices
if ncq == ncr % mu and nu are on the same FEM level (default SGFEM)
    [A,f] = mu_nu_stiffness3D_equal(ncq,m,nc,norv,KL_DATA);    
else
    if ncq > ncr % swap levels for convenience. can be done since problem is symmetric
        [A] = mu_nu_stiffness3D_nonequal(ncr,ncq,m,nc,norv,KL_DATA); 
         A = A';
    else
        [A] = mu_nu_stiffness3D_nonequal(ncq,ncr,m,nc,norv,KL_DATA);
    end
    
end
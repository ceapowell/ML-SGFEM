function [A,f] = mu_nu_stiffness_equal(ncq,m,nc,norv,KL_DATA)
% MU_NU_STIFFNESS_EQUAL stochastic coefficient stiffness matrix generation for
% same mesh levels using bilinear basis functions (Q1)
%[A,f] = mu_nu_stiffness_equal(ncq,ncr,m,nc,norv,KL_DATA)
% input
%      ncq     : FEM level for the multi-index q
%      m       : index of parameter under consideration
%      nc      : FEM levels for each multi-index
%      norv    : total number of parameters
%      KL_DATA : data from KL expansion, needed for stiffness matrices
%
% outpt
%          A   : stiffness matrix
%          f   : rhs vector
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022  A.J. Crowder, G. Papanikos, C.E. Powell

% ncq = nc(q);

[ev,~,xy,bound] = grid_data(ncq); % compute mesh data for required level

x = xy(:,1); y = xy(:,2); nvtx = length(x); nel = length(ev(:,1)); % organise required data

% A = sparse(nvtx,nvtx);
f = zeros(nvtx,1);

ngpt = 3; [oneg,onew] = gausspoints_oned(ngpt); [s,t,wt] = gausspoints_twod(oneg,onew); % setup quadrature for stiffness matrices
nngpt = ngpt^2;

A_local = zeros(nel,4,4); % initialise local LHS
f_local = zeros(nel,4); % initialise local RHS
fe = zeros(nel,4);
xl_v = x(ev); yl_v = y(ev);

for igpt = 1:nngpt
    
    sigpt = s(igpt); tigpt = t(igpt); wght = wt(igpt);
    
    [jac,invjac,phi,dphidx,dphidy] = deriv(sigpt,tigpt,xl_v,yl_v);
    
    coeff = stoch_gauss_coeff_m(sigpt,tigpt,xl_v,yl_v,norv,KL_DATA,m);
    rhs = stoch_gauss_source(sigpt,tigpt,xl_v,yl_v,0); % the RHS has no parameter dependence so we can set norv = 0 for dramatic speedup
    
    f_local = f_local + wght*rhs(:).*phi.*jac(:);
    A_local = A_local + wght*coeff(:).*( dphidx.*permute(dphidx,[1 3 2]) + dphidy.*permute(dphidy,[1,3,2]) ).*invjac(:);
end

% construct global matrix concatenating local ones
for krow = 1:4
    nrow = ev(:,krow);
    f(nrow,1) = f(nrow,1) + f_local(:,krow);
end

[Nrows,Ncols] = size(ev);
ncol = repmat(reshape(ev,Nrows*Ncols,1),4,1);

nrow = repmat(ev,Ncols,1);

A = sparse(nrow(:),ncol,A_local(:),nvtx,nvtx);

A(bound,:) = []; A(:,bound) = []; f(bound) = []; % apply zero dirichlet BCs
end

function [SG] = adaptive_multilevel_SGFEM3D(noarv,nc,indset,indset_old,SG,KL_DATA)
% ADAPTIVE_MULTILEVEL_SGFEM3D find trilinear (Q1) 
% multilevel SGFEM approximation of the stochastic 3D diffusion problem
%[SG] = adaptive_multilevel_SGFEM3D(noarv,nc,indset,indset_old,SG,KL_DATA)
% input
%      noarv      : the number of active random variables
%      nc         : FEM levels for each multi-index
%      indset     : index set
%      indset_old : index set old
%      SG         : SGFEM approximation data
%      KL_DATA    : data related to KL-expansion
%
% outpt
%      SG  :   SGFEM approximation data updated
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022  G. Papanikos, A.J. Crowder,  C.E. Powell

global iter_out eff_plot matrix_count qmethod

[P,~] = size(indset); % detemine quantity of multi-indices
[P_old,~] = size(indset_old); % detemine quantity of multi-indices

if iter_out == 1;
    fprintf('\nConstructing G and K matrices and RHS ...\n ');
end

if P_old ~= P;
    SG.G_data = adapt_stoch_gmatrices(SG.G_data,indset_old,indset,noarv);
end

N = (2.^nc-1).^3; % number of internal (solution) nodes per level

for q = 1:P; Q = SG.G_data(q,:);
    for m = 0:noarv
        if isempty(Q{m+1}) == 0; ri = Q{m+1}(:,1);
            for i = 1:length(ri)
                if m == 0 && q == 1 && ri(i) == 1
                    if isempty(SG.K{nc(1),nc(1),1})
                        matrix_count = matrix_count + 1;
                        SG.K{nc(1),nc(1),1} = mu_nu_stiffness3D(nc(1),nc(1),0,nc,noarv,KL_DATA); 
                    end
                else
                    if isempty(SG.K{nc(q),nc(ri(i)),m+1})
                        matrix_count = matrix_count + 1;
                        SG.K{nc(q),nc(ri(i)),m+1} = mu_nu_stiffness3D(nc(q),nc(ri(i)),m,nc,noarv,KL_DATA);
                        SG.K{nc(ri(i)),nc(q),m+1} = SG.K{nc(q),nc(ri(i)),m+1}';
                    end
                end
            end
        end
    end
end

% Computing the right hand side F for the first multi-index since the right
% hand side assumed to be deterministic
[~,SG.F{nc(1)}] = mu_nu_stiffness3D(nc(1),nc(1),0,nc,noarv,KL_DATA);

b = zeros(sum(N),1); b(1:length(SG.F{nc(1)})) = SG.F{(nc(1))}; % only the first block of the RHS is nonzero

if iter_out == 1; fprintf('Solving linear system using PCG ...\n '); end

nc_unique = unique(nc);
for n = 1:length(nc_unique)
    if isempty(SG.DA{nc_unique(n)})
        available_n = find(nc == nc_unique(n));
        q = available_n(1);
        Kq = squeeze(SG.K{nc(q),nc(q),1});
        SG.DA{nc_unique(n)} = Kq;
    end
end

x0 = zeros(sum(N),1);

if isempty(SG.U) == 0 % if not the first step, use unchanged modes from previous step as initial guess
    x0 = mat2cell(x0,N,1);
    for mu = 1:P_old; if length(SG.U{mu}) == N(mu); x0{mu} = SG.U{mu}; end; end
    x0 = cell2mat(x0);
end


nterms = 1; % number of terms in precond expansion (1 = mean-based preconditioning)
[u,flag,~,iter] = pcg(@(x)multilevel_matvec_prod(x,SG.G_data,SG.K,noarv,nc),b,1e-8,100,@(x)adapt_multilevel_precond_inv(x,nc,SG.G_data,SG.K,SG.DA,noarv,nterms),[],x0);

if iter_out == 1; cprintf('-text','completed\n'); %fprintf('Number of PCG iterations: %d\n',iter); end
    if flag ==0
        fprintf('PCG converged to the desired tolerance within %d iterations\n',iter);
    elseif flag ==1
        fprintf('PCG iterated %d times but did not converge\n',iter)
    elseif flag ==2
        fprintf('preconditioner M was ill-conditioned\n')
    elseif flag ==3
        fprintf('PCG stagnated (two consecutive iterates were the same).\n')
        error('The problem might be ill-posed!');
    else
        fprintf('one of the scalar quantities calculated during PCG became too small or too large to continue computing\n')
        error('The problem might be ill-posed!')
    end
end
SG.U = mat2cell(u,N,1);

if iter_out == 1;
    cprintf('-text','completed\n');
end
if eff_plot
    [SG.ref_error,SG.stoch_energy] = stoch_energy_error(SG.G_data,SG.K,noarv,nc,SG.U);
else
    [~,SG.stoch_energy] =     stoch_energy_error(SG.G_data,SG.K,noarv,nc,SG.U);
end % compute reference error or the energy norm of the solution

function G_data = adapt_stoch_gmatrices(G_data_old,indset_old,indset,noarv)
%ADAPT_STOCH_GMATRICES generates stochastic G-matrices
% G_data = adapt_stoch_gmatrices(G_data_old,indset_old,indset,noarv);
%   input
%          G_data_old : Stochastic matrices     
%          indset_old : old multi index set        
%          indset     : new multi index set    
%          noarv      : number of active random variables
%   output
%          G_data          a (1 x (norv+1)) cell of G-matrices
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022  A. J. Crowder, G. Papanikos, C.E. Powell
P = size(indset,1); P_old = size(indset_old,1); I = eye(noarv,'uint8');

G_data = cell(P,noarv+1);

if P_old == 0
    
%     for k = 1:P % populate data regarding G0
%         G_data{k,1} = [k 1];
%     end

    G_data(1:P,1) = mat2cell([1:P;ones(1,P)]',ones(P,1),2); % populate data regarding G0
    for m = 1:noarv
        G_data = find_stoch_entries(m,G_data,noarv,P,P,0,0,indset,indset,I);
    end
    
else
    
    indset_new = indset(P_old+1:end,:);
    P_new = size(indset_new,1);
    
    [~,nz,~] = find(indset_old);
    noarv_old = max(nz);
    
    G_data(1:P_old,1:noarv_old+1) = G_data_old;

%     for k = P_old+1:P % populate data regarding G0
%         G_data{k,1} = [k 1];
%     end

    G_data(P_old+1:P,1) = mat2cell([P_old+1:P;ones(1,P-P_old)]',ones(P-P_old,1),2); % populate data regarding G0
    for m = 1:noarv         
        G_data = find_stoch_entries(m,G_data,noarv,P,P_new,0,P_old,indset,indset_new,I); % P with P_new i.e. P_old with P_new and P_new with P_new
    end
    
end

end

function G_data = find_stoch_entries(m,G_data,noarv,P_testing1,P_testing2,k_diff,n_diff,test_indset1,test_indset2,I)

for k = 1:P_testing1
    
    nu = test_indset1(k,1:noarv) + I(m,:);
    [s,n] = max(sum(test_indset2(:,1:noarv)==nu,2));
    
    if s == noarv
        G_data{k+k_diff,m+1} = [G_data{k+k_diff,m+1}; n+n_diff double(nu(m))/(sqrt(4.0e0*double(nu(m))^2-1.0e0))];
        G_data{n+n_diff,m+1} = [G_data{n+n_diff,m+1}; k+k_diff double(nu(m))/(sqrt(4.0e0*double(nu(m))^2-1.0e0))];
    end
    
end

end






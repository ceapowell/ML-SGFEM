function ff = stoch_gauss_source3D(s,t,l,xl,yl,zl,norv)
%STOCH_GAUSS_SOURCE3D evaluates stochastic source term at Gauss point 
%   ff = stoch_gauss_source3D(s,t,l,xl,yl,zl,norv);
%   input
%          s         reference element x coordinate   
%          t         reference element y coordinate
%          l         reference element z coordinate
%          xl        physical element x vertex coordinates 
%          yl        physical element y vertex coordinates
%          zl        physical element y vertex coordinates
%          norv      number of random variables
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell

  nel=length(xl(:,1));
  zero_v = zeros(nel,1); xx=zero_v; yy=xx; zz=xx;
  [phi_e,~,~,~] = shape3D(s,t,l);
  for ivtx=1:8 
      xx = xx + phi_e(ivtx) * xl(:,ivtx);
      yy = yy + phi_e(ivtx) * yl(:,ivtx);
      zz = zz + phi_e(ivtx) * zl(:,ivtx);
  end
  ff=stoch_specific_rhs3D(xx,yy,zz, nel,norv);
  return
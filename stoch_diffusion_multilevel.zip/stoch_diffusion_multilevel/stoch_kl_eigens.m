function KL_DATA = stoch_kl_eigens(ax,ay,std_dev,correl_x,correl_y,norv2d)
%STOCH_KL_EIGENS computes KL eigenvalues for the covariance function
%
%        exp(-|x_{1}-y_{1}|/correl_x - |x_{2} - y_{2}|/correl_y)
%         
%   KL_DATA = stoch_kl_eigens(ax,ay,std_dev,correl_x,correl_y,norv2d);
%   input
%       the domain  [-ax, ax] times [-ay, ay]
%       std_dev     standard deviation
%       correl_x    x-direction correlation length
%       correl_y    y-direction correlation length
%       norv2d      number of RVs in each direction
%
%   output
%        KL_DATA    structure 
%
% calls fzero for embedded functions: oddfun; evenfun
%
% Based on KLExpansion.m, a subroutine that is part of the FERUM 3.1
% software package written by Armen Der Kiureghian et al., Berkeley. 
%
% SIFISS function: CEP; 23 August 2013, DJS; 1 May 2015.
% Copyright (c) 2013 A. Bespalov, C.E. Powell, D.J. Silvester

% set anonymous functions
oddfun  = @(z,a,c) c-z*tan(a*z);
evenfun = @(z,a,c) z+c*tan(a*z);

% set the number of r.v. in each 1d direction
  norv1d = norv2d;
%
% invert correlation lengths
  cx = 1/correl_x; cy = 1/correl_y;

% initialisation
  omega_x=zeros(1,norv1d);
  omega_y=zeros(1,norv1d);
  aux_ones=ones(1,norv1d);

% special case: n=1
  x0 = [0, pi/(2*ax) - 1.0e-08];
  y0 = [0, pi/(2*ay) - 1.0e-08];
  omega_x(1) = fzero(@(z,a,c) oddfun(z,ax,cx), x0);
  omega_y(1) = fzero(@(z,a,c) oddfun(z,ay,cy), y0);
  indic(1) = 1; % indication that 1 is odd, and the eigenfunction is cos

% n = 2:norv1d
  for n = 2:norv1d
      k = floor(n/2);
      x0 = [(2*k-1)*pi/(2*ax) + 1.0e-08, (2*k+1)*pi/(2*ax) - 1.0e-08];
      y0 = [(2*k-1)*pi/(2*ay) + 1.0e-08, (2*k+1)*pi/(2*ay) - 1.0e-08];
      if mod(n,2) == 1
         omega_x(n) = fzero(@(z,a,c) oddfun(z,ax,cx), x0);
         omega_y(n) = fzero(@(z,a,c) oddfun(z,ay,cy), y0);
         indic(1,n) = 1; % indication that n is odd, and the eigenfunction is cos
         else
         omega_x(n) = fzero(@(z,a,c) evenfun(z,ax,cx), x0);
         omega_y(n) = fzero(@(z,a,c) evenfun(z,ay,cy), y0);
         indic(1,n) = -1; % indication that n is even, and the eigenfunction is sin
      end
  end

% compute 'directional' eigenvalues
  lambda_x = 2*cx*aux_ones./(omega_x.^2 + cx^2*aux_ones);
  lambda_y = 2*cy*aux_ones./(omega_y.^2 + cy^2*aux_ones);

% compute 'directional' normalisation coefficients
  alpha_x = aux_ones./sqrt(ax*aux_ones + indic.*sin(2*ax*omega_x)./(2*omega_x));
  alpha_y = aux_ones./sqrt(ay*aux_ones + indic.*sin(2*ay*omega_y)./(2*omega_y));

% find 2d eigenvalues, sort them out keeping track of their 'directional' indices
  eigaux_2d = lambda_x' * lambda_y;
  [eigaux_2d_sorted,ind_sorted] = sort(eigaux_2d(:)','descend');
  [indaux_x,indaux_y]=ind2sub([norv1d norv1d],ind_sorted);

% assign values to the fields of the structure KL_DATA
  KL_DATA.input = [ax,ay,std_dev,correl_x,correl_y];
%
  KL_DATA.ev2d = eigaux_2d_sorted(1:norv2d);
%
  KL_DATA.ev2d_ind(:,1) = indaux_x(1:norv2d)';
  KL_DATA.ev2d_ind(:,2) = indaux_y(1:norv2d)';
%
  KL_DATA.ev_x(:,1) = lambda_x(1:norv1d);
  KL_DATA.ev_x(:,2) = omega_x(1:norv1d);
  KL_DATA.ev_x(:,3) = alpha_x(1:norv1d);
%
  KL_DATA.ev_y(:,1) = lambda_y(1:norv1d);
  KL_DATA.ev_y(:,2) = omega_y(1:norv1d);
  KL_DATA.ev_y(:,3) = alpha_y(1:norv1d);
%
  KL_DATA.ef_indic = indic;

return

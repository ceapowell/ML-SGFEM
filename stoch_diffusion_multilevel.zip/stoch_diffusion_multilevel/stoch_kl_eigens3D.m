function KL_DATA = stoch_kl_eigens3D(ax,ay,az,std_dev,correl_x,correl_y,correl_z,norv3d)
%STOCH_KL_EIGENS3D computes KL eigenvalues for the covariance function
%
%        exp(-|x_{1}-y_{1}|/correl_x - |x_{2} - y_{2}|/correl_y- |x_{3} - y_{3}|/correl_z)
%         
%   KL_DATA = stoch_kl_eigens(ax,ay,az,std_dev,correl_x,correl_y,correl_z,norv3d);
%   input
%       the domain  [-ax, ax] times [-ay, ay] times [-az, az]
%       std_dev     standard deviation
%       correl_x    x-direction correlation length
%       correl_y    y-direction correlation length
%       correl_z    z-direction correlation length
%       norv3d      number of RVs in each direction
%
%   output
%        KL_DATA    structure 
%
% calls fzero for embedded functions: oddfun; evenfun
%
% Based on KLExpansion.m, a subroutine that is part of the FERUM 3.1
% software package written by Armen Der Kiureghian et al., Berkeley. 
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell


% set anonymous functions
oddfun  = @(z,a,c) c-z*tan(a*z);
evenfun = @(z,a,c) z+c*tan(a*z);

% set the number of r.v. in each 1d direction
  norv1d = norv3d;
%
% invert correlation lengths
  cx = 1/correl_x; cy = 1/correl_y; cz = 1/correl_z;

% initialisation
  omega_x=zeros(1,norv1d);
  omega_y=zeros(1,norv1d);
  omega_z=zeros(1,norv1d);
  aux_ones=ones(1,norv1d);

% special case: n=1
  x0 = [0, pi/(2*ax) - 1.0e-08];
  y0 = [0, pi/(2*ay) - 1.0e-08];
  z0 = [0, pi/(2*az) - 1.0e-08];
  
  omega_x(1) = fzero(@(z,a,c) oddfun(z,ax,cx), x0);
  omega_y(1) = fzero(@(z,a,c) oddfun(z,ay,cy), y0);
  omega_z(1) = fzero(@(z,a,c) oddfun(z,az,cz), z0);
  
  indic(1) = 1; % indication that 1 is odd, and the eigenfunction is cos

% n = 2:norv1d
  for n = 2:norv1d
      k = floor(n/2);
      x0 = [(2*k-1)*pi/(2*ax) + 1.0e-08, (2*k+1)*pi/(2*ax) - 1.0e-08];
      y0 = [(2*k-1)*pi/(2*ay) + 1.0e-08, (2*k+1)*pi/(2*ay) - 1.0e-08];
      z0 = [(2*k-1)*pi/(2*az) + 1.0e-08, (2*k+1)*pi/(2*az) - 1.0e-08];
      if mod(n,2) == 1
         omega_x(n) = fzero(@(z,a,c) oddfun(z,ax,cx), x0);
         omega_y(n) = fzero(@(z,a,c) oddfun(z,ay,cy), y0);
         omega_z(n) = fzero(@(z,a,c) oddfun(z,az,cz), z0);
         indic(1,n) = 1; % indication that n is odd, and the eigenfunction is cos
         else
         omega_x(n) = fzero(@(z,a,c) evenfun(z,ax,cx), x0);
         omega_y(n) = fzero(@(z,a,c) evenfun(z,ay,cy), y0);
         omega_z(n) = fzero(@(z,a,c) evenfun(z,az,cz), z0);
         indic(1,n) = -1; % indication that n is even, and the eigenfunction is sin
      end
  end

% compute 'directional' eigenvalues
  lambda_x = 2*cx*aux_ones./(omega_x.^2 + cx^2*aux_ones);
  lambda_y = 2*cy*aux_ones./(omega_y.^2 + cy^2*aux_ones);
  lambda_z = 2*cz*aux_ones./(omega_z.^2 + cz^2*aux_ones);
% compute 'directional' normalisation coefficients
  alpha_x = aux_ones./sqrt(ax*aux_ones + indic.*sin(2*ax*omega_x)./(2*omega_x));
  alpha_y = aux_ones./sqrt(ay*aux_ones + indic.*sin(2*ay*omega_y)./(2*omega_y));
  alpha_z = aux_ones./sqrt(az*aux_ones + indic.*sin(2*az*omega_z)./(2*omega_z));

% find 3d eigenvalues, sort them out keeping track of their 'directional' indices
%   eigaux_3d = zeros(size(lambda_x,2),size(lambda_y,2),size(lambda_z,2));
 %   for i = 1:size(lambda_z,2)
        eigaux_3d = reshape(kron(lambda_x' * lambda_y,lambda_z),size(lambda_x,2),size(lambda_y,2),size(lambda_z,2));
  %  end
  
  [eigaux_3d_sorted,ind_sorted] = sort(eigaux_3d(:)','descend');
  [indaux_x,indaux_y,indaux_z]=ind2sub([norv1d norv1d norv1d],ind_sorted);

% assign values to the fields of the structure KL_DATA
  KL_DATA.input = [ax,ay,az,std_dev,correl_x,correl_y,correl_z];
%
  KL_DATA.ev3d = eigaux_3d_sorted(1:norv3d);
%
  KL_DATA.ev3d_ind(:,1) = indaux_x(1:norv3d)';
  KL_DATA.ev3d_ind(:,2) = indaux_y(1:norv3d)';
  KL_DATA.ev3d_ind(:,3) = indaux_z(1:norv3d)';
%
  KL_DATA.ev_x(:,1) = lambda_x(1:norv1d);
  KL_DATA.ev_x(:,2) = omega_x(1:norv1d);
  KL_DATA.ev_x(:,3) = alpha_x(1:norv1d);
%
  KL_DATA.ev_y(:,1) = lambda_y(1:norv1d);
  KL_DATA.ev_y(:,2) = omega_y(1:norv1d);
  KL_DATA.ev_y(:,3) = alpha_y(1:norv1d);

%
  KL_DATA.ev_z(:,1) = lambda_z(1:norv1d);
  KL_DATA.ev_z(:,2) = omega_z(1:norv1d);
  KL_DATA.ev_z(:,3) = alpha_z(1:norv1d); 
%
  KL_DATA.ef_indic = indic;

return

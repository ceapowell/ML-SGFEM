function [phi,dphids,dphidt] = vshape(s,t)
%VSHAPE evaluates bilinear shape functions
%   [phi,dphids,dphidt] = shape(s,t);
%   input
%          s         x coordinate
%          t         y coordinate
%   output
%          phi        shape function
%          dphids     x derivative of phi
%          dphidt     y derivative of phi
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell
%
% vectorized version of IFISS function SHAPE
% authors: D.J. Silvester, H.C. Elman, A. Ramage


n=length(s);

% one = ones(n,1);

phi = zeros(n,4);
dphids = zeros(n,4);
dphidt = zeros(n,4);

sm1 = s(:) - 1; sp1 = s(:) + 1;
tm1 = t(:) - 1; tp1 = t(:) + 1;

phi(:,1) = 0.25 * sm1 .* tm1;
phi(:,2) = -.25 * sp1 .* tm1;
phi(:,3) = 0.25 * sp1 .* tp1;
phi(:,4) = -.25 * sm1 .* tp1;
dphids(:,1) = 0.25 * tm1;
dphids(:,2) = -.25 * tm1;
dphids(:,3) = 0.25 * tp1;
dphids(:,4) = -.25 * tp1;
dphidt(:,1) = 0.25 * sm1;
dphidt(:,2) = -.25 * sp1;
dphidt(:,3) = 0.25 * sp1;
dphidt(:,4) = -.25 * sm1;


return

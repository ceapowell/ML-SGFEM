function [jac,invjac,phi,dphidx,dphidy] = vderiv(s,t,xl,yl)
%VDERIV evaluates derivatives of bilinear shape functions
%   [jac,invjac,phi,dphidx,dphidy] = vderiv(s,t,xl,yl);
%   input
%          s         reference element x coordinate
%          t         reference element y coordinate
%          xl        physical element x vertex coordinates
%          yl        physical element y vertex coordinates
%   output
%          jac       elementwise jacobian (evaluated at (s,t))
%          invjac    elementwise inverse of jacobian
%          phi       elementwise shape functions
%          dphidx    x derivatives of phi
%          dphidy    y derivatives of phi
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell
%
% vectorized version of IFISS function DERIV
% authors: D.J. Silvester, H.C. Elman, A. Ramage
ns = length(s);
zero_v = zeros(ns,1);

% evaluate shape functions
[phi_e,dphids,dphidt] = vshape(s,t);

dxds = zero_v;
dxdt = zero_v;
dyds = zero_v;
dydt = zero_v;


for ivtx = 1:4
    dxds(:) = dxds(:) + xl(:,ivtx) .* dphids(:,ivtx);
    dxdt(:) = dxdt(:) + xl(:,ivtx) .* dphidt(:,ivtx);
    dyds(:) = dyds(:) + yl(:,ivtx) .* dphids(:,ivtx);
    dydt(:) = dydt(:) + yl(:,ivtx) .* dphidt(:,ivtx);
end

jac(:) = dxds(:).*dydt(:) - dxdt(:).*dyds(:);
invjac(:) = 1 ./ jac(:);


phi = phi_e;
dphidx = dphids.*dydt(:) - dphidt.*dyds(:);
dphidy = dphidt.*dxds(:) - dphids.*dxdt(:);


return

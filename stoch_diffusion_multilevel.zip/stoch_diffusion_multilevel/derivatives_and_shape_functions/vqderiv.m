function [invjac,psi,dpsidx,dpsidy] = vqderiv(s,t,xl,yl)
%VQDERIV evaluates derivatives of biquadratic shape functions vectorized
%version
%   [invjac,psi,dpsidx,dpsidy] = vqderiv(s,t,xl,yl);
%   input
%          s         reference element x coordinate
%          t         reference element y coordinate
%          xl        physical element x vertex coordinates
%          yl        physical element y vertex coordinates
%   output
%          invjac    inverse jacobian
%          psi       elementwise shape functions
%          dpsidx    x derivatives of psi
%          dpsidy    y derivatives of psi
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell
%
% vectorized version of IFISS function QDERIV
% authors: D.J. Silvester, H.C. Elman, A. Ramage

ns = length(s);
zero_v = zeros(ns,1);
one_v = ones(ns,1);

% evaluate bilinear shape functions
[phi_e,dphids,dphidt] = vshape(s,t);
% evaluate biquadratic shape functions
[psi_e,dpsids,dpsidt] = vqshape(s,t);
% local derivatives
dxds = zero_v;
dxdt = zero_v;
dyds = zero_v;
dydt = zero_v;


for ivtx = 1:4
    dxds(:) = dxds(:) + xl(:,ivtx) .* dphids(:,ivtx);
    dxdt(:) = dxdt(:) + xl(:,ivtx) .* dphidt(:,ivtx);
    dyds(:) = dyds(:) + yl(:,ivtx) .* dphids(:,ivtx);
    dydt(:) = dydt(:) + yl(:,ivtx) .* dphidt(:,ivtx);
end

jac(:) = dxds(:).*dydt(:) - dxdt(:).*dyds(:);
invjac(:) = one_v ./ jac(:);

psi = psi_e;
dpsidx =  dpsids.*dydt(:)-dpsidt.*dyds(:);
dpsidy =  dpsidt.*dxds(:)-dpsids.*dxdt(:);
return


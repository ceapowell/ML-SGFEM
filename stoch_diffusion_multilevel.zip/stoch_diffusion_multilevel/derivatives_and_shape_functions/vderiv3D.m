function [jac,invjac,phi,dphidx,dphidy,dphidz] = vderiv3D(s,t,l,xl,yl,zl)
%VDERIV3D evaluates derivatives of trilinear vector shape functions
%   [jac,invjac,phi,dphidx,dphidy,dphidz] = deriv(s,t,l,xl,yl,zl);
%   input
%          s         reference element x coordinate
%          t         reference element y coordinate
%          l         reference element z coordinate
%          xl        physical element x vertex coordinates
%          yl        physical element y vertex coordinates
%          zl        physical element z vertex coordinates
%   output
%          jac       elementwise jacobian (evaluated at (s,t,l))
%          invjac    elementwise inverse of jacobian
%          phi       elementwise shape functions
%          dphidx    x derivatives of phi
%          dphidy    y derivatives of phi
%          dphidz    z derivatives of phi
%
% vectorized version of Multilevel SGFEM function DERIV3D
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell
%
ns = size(s,1);
zero_v = zeros(ns,1);
% evaluate shape functions
[phi_e,dphids,dphidt,dphidl] = vshape3D(s,t,l);
dphids = dphids'; dphidt = dphidt'; dphidl = dphidl';
%
dxds = zero_v;
dxdt = zero_v;
dxdl = zero_v;
dyds = zero_v;
dydt = zero_v;
dydl = zero_v;
dzds = zero_v;
dzdt = zero_v;
dzdl = zero_v;

jac = zero_v;
invjac = zero_v;
%
for ivtx = 1:8
    dxds(:) = dxds(:) + xl(:,ivtx) .* dphids(:,ivtx);
    dxdt(:) = dxdt(:) + xl(:,ivtx) .* dphidt(:,ivtx);
    dxdl(:) = dxdl(:) + xl(:,ivtx) .* dphidl(:,ivtx);
    
    dyds(:) = dyds(:) + yl(:,ivtx) .* dphids(:,ivtx);
    dydt(:) = dydt(:) + yl(:,ivtx) .* dphidt(:,ivtx);
    dydl(:) = dydl(:) + yl(:,ivtx) .* dphidl(:,ivtx);
    
    dzds(:) = dzds(:) + zl(:,ivtx) .* dphids(:,ivtx);
    dzdt(:) = dzdt(:) + zl(:,ivtx) .* dphidt(:,ivtx);
    dzdl(:) = dzdl(:) + zl(:,ivtx) .* dphidl(:,ivtx);
    
end

jac =  dxds.*(dydt.*dzdl - dydl.*dzdt)...
    -dxdt.*(dyds.*dzdl - dydl.*dzds)...
    +dxdl.*(dyds.*dzdt - dydt.*dzds);
%
% check element Jacobian
if any(jac < 1e-9)
    fprintf('Bad element warning ...\n')
    if any(jac <= 0.0)
        error('singular Jacobian ... Aborted ...')
    end
end
invjac(:) = 1./ jac(:);
%

phi = phi_e;

alpha  = dydt.*dzdl - dydl.*dzds;
beta   = dxdt.*dzdl - dxdl.*dzdt;
gamma  = dxdt.*dydl - dxdl.*dydt;

delta   = dyds.*dzdl - dydl.*dzds;
epsilon = dxds.*dzdl - dxdl.*dzds;
zeta    = dxds.*dydl - dxdl.*dyds;

eta   = dyds.*dzdt - dydt.*dzds;
theta = dxds.*dzdt - dxdt.*dzds;
iota  = dxds.*dydt - dxdt.*dydl;


dphidx = (dphids.*alpha(:) - dphidt.*beta(:)+dphidl.*gamma(:));
dphidy = (-dphids.*delta(:) + dphidt.*epsilon(:)-dphidl.*zeta(:));
dphidz = (dphids.*eta(:) - dphidt.*theta(:)+dphidl.*iota(:));

return
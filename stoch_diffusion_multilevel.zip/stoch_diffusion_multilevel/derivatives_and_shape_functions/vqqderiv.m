function [invjac,qua,dquadx,dquady] = vqqderiv(s,t,xl,yl)
%VQQDERIV evaluates derivatives of biquartic shape functions
%   [quar,dquardx,dquardy] = qqderiv(s,t,xl,yl);
%   input
%          s         reference element x coordinate
%          t         reference element y coordinate
%          xl        physical element x vertex coordinates
%          yl        physical element y vertex coordinates
%   output
%          qua       elementwise shape functions
%          dquadx    x derivatives of qar
%          dquady    y derivatives of qar
%          invjac    inverse of the jacobian
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell
%
% vectorized version of IFISS function QQDERIV
% authors: D.J. Silvester, H.C. Elman, A. Ramage

nel=length(xl(:,1));
zero_v = zeros(nel,1);
one_v = ones(nel,1);
%
% evaluate bilinear shape functions
[~,dphids,dphidt] = vshape(s,t);
% evaluate biquadratic shape functions
[qua_e,dquads,dquadt] = vqqshape(s,t);
% local derivatives
dxds = zero_v;
dxdt = zero_v;
dyds = zero_v;
dydt = zero_v;


for ivtx = 1:4
    dxds(:) = dxds(:) + xl(:,ivtx) .*dphids(:,ivtx);
    dxdt(:) = dxdt(:) + xl(:,ivtx) .*dphidt(:,ivtx);
    dyds(:) = dyds(:) + yl(:,ivtx) .*dphids(:,ivtx);
    dydt(:) = dydt(:) + yl(:,ivtx) .*dphidt(:,ivtx);
end
%
jac(:) = dxds(:).*dydt(:) - dxdt(:).*dyds(:);
invjac(:) = one_v ./ jac(:);
% check element Jacobian
if any(jac < 1e-9)
    fprintf('Bad element warning ...\n')
    if any(jac <= 0.0)
        error('singular Jacobian ... Aborted ...')
    end
end

qua = qua_e;
dquadx =  dquads.*dydt(:)-dquadt.*dyds(:);
dquady =  -dquads.*dxdt(:)+dquadt.*dxds(:);

return

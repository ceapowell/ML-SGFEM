function [ref_error,stoch_energy] = stoch_energy_error(G_data,K,noarv,nc,U)
% STOCH_ENERGY_ERROR computes energy norm of the difference between the
% reference solution and the SGFEM approximation and the energy norm of the
% SGFEM approximation
% [ref_error,stoch_energy] = stoch_energy_error(G_data,K,noarv,nc,U)
% input
%      G_data       : Data for G matrices
%      K            : LHS FEM matrices
%      noarv        : number of active parameters
%      nc           : FEM levels for each multi-index
%      U            : SFGEM Solution
%
% outpt
%      ref_error    : energy norm of the error
%      stoch_energy : energy norm of the SGFEM solution
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell

global TP iter_out eff_plot

if iter_out == 1 && eff_plot == 1
    fprintf('\nComputing reference energy error ... ')
elseif iter_out == 1 && eff_plot == 0
    fprintf('\nComputing Energy norm of the solution ... ')
end
u = cell2mat(U);
stoch_energy = sqrt(u'*multilevel_matvec_prod(u,G_data,K,noarv,nc));% compute energy norm of current SGFEM approximation
ref_error = [];

if iter_out == 1 && eff_plot == 1 || iter_out == 0 && eff_plot == 1
    
    if TP == 1
        % TP2
        energy_ref = 1.50349278e-01; %reference solution computed using multilevel algorithm with Q2 approximation and tolerance 9.4691e-04.
    elseif TP == 2
        % TP5 - slow
        energy_ref = 1.90117126e-01; % reference solution computed using multilevel algorithm with Q2 approximation and tolerance 2.8482e-05.
    elseif TP == 3
        % TP5 - fast
        energy_ref = 1.94141992e-01; % reference solution computed using the multilevel algorithm with Q2 approximation and tolerance 1e-5.
    elseif TP == 4
        % TP6
        energy_ref =  1.34260176954214e-01; % reference solution computed using the multilevel algorithm with Q2 approximation and tolerance 5e-6
      
    elseif TP == 5
        % TP5 - fast
        energy_ref = 4.81853315697494e-01;  % L shape domain (reference solution computed using the multilevel algorithm with Q2 approximation and tolerance = 1.189e-03.
    elseif  TP == 6
        % TP5 slow
        energy_ref =  4.70146168370387e-01; % L shape domain (reference solution computed using the multilevel algorithm with Q2 approximation and tolerance = 1.361e-03.
    end
    
    ref_error = sqrt((energy_ref^2) - (stoch_energy^2));
    if iter_out ==1
        cprintf('-text','completed\n');
        fprintf('         Solution energy        = %9.8e.\n',stoch_energy)
        fprintf('         Reference energy error = %5.4e.\n',ref_error)
    end
elseif iter_out == 1 && eff_plot ==0
    cprintf('-text','completed\n');
    fprintf('         Solution energy        = %9.8e.\n',stoch_energy)
    
end

function UUU = multi_stats(U,P,nc,indset,noarv)
% MULTI_STATS this function interpolates the 2D solution at each level to the finest
% level required to easily visualise and evalutate mean and var.
% UUU = multi_stats(U,P,nc,indset,noarv)
% input
%      U           : SFGEM Solution
%      nc          : FEM levels for each multi-index
%      indset      : index set
%      noarv       : number of active parameters
%
% outpt
%      UUU         :  SGFEM solution
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell

global TP dom_type
fprintf('\nComputing statistics ... ')


nc_max = max(nc);

n_x_steps_max = 2^(nc_max) + 1;
mm = size(nc,2)-1;

rows = sqrt(mm);


if isinteger(rows)==1
    cols = rows;
else
    rows = round(sqrt(mm));
    cols = round(sqrt(mm))+1;
end


count =1;
if TP == 1 || TP ==5 || TP ==6
    x_steps_max = linspace(-1,1,n_x_steps_max);
    x_mean = 0;
    y_mean = 0;
end
if TP == 2 || TP == 3 || TP == 4
    x_steps_max = linspace(0,1,n_x_steps_max);
end

y_steps_max = x_steps_max;

[~,~,xy_max,bound_max] = grid_data(nc_max);
[X_max,Y_max] = meshgrid(x_steps_max,y_steps_max);

UUU = cell(1,P);

if P == 4  % initialise figure
    figure(252)
end

u = cell2mat(U);
U_gal = u_gal_reconstruct(u,nc); % add zeros to solution from boundary nodes and split into P pieces

for p = 1:P
    
    if nc(p) < nc_max
        
        [~,~,xy,~] = grid_data(nc(p));
        
        n_x_steps = 2^(nc(p)) + 1;
        
        if TP == 1 || TP == 5 || TP == 6
            x_steps = linspace(-1,1,n_x_steps);
        end
        if TP == 2 || TP == 3 || TP == 4
            x_steps = linspace(0,1,n_x_steps);
        end
        
        y_steps = x_steps;
        
        [X,Y] = meshgrid(x_steps,y_steps);
        
        sol_len = size(xy,1);
        if isequal(dom_type,'square')
            UU = reshape(U_gal{p},sqrt(sol_len),sqrt(sol_len));
            
            UUU{p} = interp2(X,Y,UU,X_max,Y_max)';
            
            if P == 4
                subplot(2,P/2,p)
                contourf(X,Y,UU,12) % 12 contour levels
                colorbar
                axis square
            end
            
        else
            e_xysol = griddata(xy(:,1),xy(:,2),U_gal{p},X,Y);
            [II,JJ]=find(X<x_mean & Y<y_mean); e_xysol(II,JJ)=nan;
            UUU{p} = interp2(X,Y,e_xysol,X_max,Y_max);
            
            if P == 4
                subplot(2,P/2,p)
                contourf(X,Y,e_xysol,12) % 12 contour levels
                colorbar
                axis square
            end
        end
        
        
    else
        
        sol_len = size(xy_max,1);
        
        non_bound = setdiff(1:sol_len,bound_max);
        
        UU = zeros(sol_len,1);
        UU(non_bound) = U{p};
        
        if isequal(dom_type,'square')
            UUU{p} = reshape(UU,sqrt(sol_len),sqrt(sol_len))';
            
            
        else
            e_xysol = griddata(xy_max(:,1),xy_max(:,2),UU,X_max,Y_max);
            [II,JJ]=find(X_max<x_mean & Y_max<y_mean); e_xysol(II,JJ)=nan;
            UUU{p} = e_xysol;
        end
    end
    
end

E = UUU{1}; V = UUU{2}.^2; % store mean and initialise variance

if P > 2
    for i = 3:P
        V = V + UUU{i}.^2;
    end
end

mean = E;
var = V;

max_mean = max(max(mean));
max_var = max(max(var)); cprintf('-text','completed\n');

str_max_mean = ['Max expectation = ',num2str(max_mean,'%5.4e'),'.'];
str_max_var  = ['Max variance = ',num2str(max_var,'%5.4e'),'.'];

disp(['  ',str_max_mean]) % display in command window
disp(['     ',str_max_var])

figure(250)

subplot(2,2,1)
contourf(X_max,Y_max,E,12) % 8 contour levels
colorbar
axis square
title({'{\bf\fontsize{12}Expectation}',str_max_mean,''},'FontWeight','Normal','FontSize',10) % add blank third title line
subplot(2,2,2)
mesh(X_max,Y_max,E)
colorbar
axis square

subplot(2,2,3)
contourf(X_max,Y_max,V,12)
colorbar
axis square
title({'{\bf\fontsize{12}Variance}',str_max_var,''},'FontWeight','Normal','FontSize',10)
subplot(2,2,4)
mesh(X_max,Y_max,V)
colorbar
axis square





for p = 1:P
    UUU{p} = reshape(UUU{p}',[],1);
end
UUU = cell2mat(UUU);


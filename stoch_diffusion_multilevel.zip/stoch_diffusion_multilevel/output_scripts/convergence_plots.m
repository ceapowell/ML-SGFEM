% Plot errors  and effectivity indices
% Multilevel SGFEM scriptfile: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A. J. Crowder, C.E. Powell
global eff_plot qmethod

if plot_aprox_err
    
    p = polyfit(log(DOFs_iter),log(ERRs_iter),1);
    xnew = [0.25*DOFs_iter(1) 3.5*DOFs_iter(end)];
    f = xnew.^p(1).*exp(p(2));
    
    figure(1)
    if eff_plot == 1; subplot(1,2,1); end
    
    loglog(xnew,f,'c-','Linewidth',1.5);  hold on
    
    if eff_plot == 1
        loglog(DOFs_iter,ERRs_ref_iter,'k-^',DOFs_iter,ERRs_iter,'m-o','Linewidth',1.5); hold on
        loglog(DOFs_iter,s_er_iter,'b-d',DOFs_iter,p_er_iter,'g-s','Linewidth',1.5);
    else
        loglog(DOFs_iter,ERRs_iter,'k-o','Linewidth',1.5); hold on
        loglog(DOFs_iter,s_er_iter,'b-d',DOFs_iter,p_er_iter,'g-s','Linewidth',1.5);
    end
    
    xlabel('#DOF');
    title('Convergence of Estimated Energy Error');
    axis square; grid on; grid minor; h = sprintf('dof^{%3.2f}',p(1));
    
    if eff_plot == 1
        if qmethod == 1
            if dim == 2
                if error_space == 1
                    legend({h,'reference','total estimated error','Q2(h) spatial estimated error','parametric estimated error'},'FontSize',14);
                else
                    legend({h,'reference','total estimated error','Q1(h/2) spatial estimated error','parametric estimated error'},'FontSize',14);
                end
            else
                if error_space == 1
                    legend({h,'reference','total estimated error','full Q2(h) spatial estimated error','parametric estimated error'},'FontSize',14);
                else
                    legend({h,'reference','total estimated error','reduced Q2(h) spatial estimated error','parametric estimated error'},'FontSize',14);
                end
            end
        else
            if error_space == 1
                legend({h,'reference','total estimated error','Q4(h) spatial estimated error','parametric estimated error'},'FontSize',14);
            else
                legend({h,'reference','total estimated error','Q2(h/2) spatial estimated error','parametric estimated error'},'FontSize',14);
            end
        end
    else
        if qmethod == 1
            if dim ==2
                if error_space == 1
                    legend({h,'total estimated error','Q2(h) spatial estimated error','parametric estimated error'},'FontSize',14);
                else
                    legend({h,'total estimated error','Q1(h/2) spatial estimated error','parametric estimated error'},'FontSize',14);
                end
            else
                if error_space == 1
                    legend({h,'total estimated error','full Q2(h) spatial estimated error','parametric estimated error'},'FontSize',14);
                else
                    legend({h,'total estimated error','reduced Q2(h) spatial estimated error','parametric estimated error'},'FontSize',14);
                end
            end
        else
            if error_space == 1
                legend({h,'total estimated error','Q4(h) spatial estimated error','parametric estimated error'},'FontSize',14);
            else
                legend({h,'total estimated error','Q2(h/2) spatial estimated error','parametric estimated error'},'FontSize',14);
            end
        end
    end
    
end

if eff_plot == 1
    if  plot_aprox_err == 0
        plot(1:length(EFFs_iter),EFFs_iter,'m-o','Linewidth',1.5)
        axis square; grid on; grid minor; xlabel('Algorithm step'); title('Estimated Effectivity Indices');
    else
        subplot(1,2,2); plot(1:length(EFFs_iter),EFFs_iter,'m-o','Linewidth',1.5)
        axis square; grid on; grid minor; xlabel('Algorithm step'); title('Estimated Effectivity Indices');
    end
end
function UUU = multi_stats3D(U,P,nc,indset,noarv)
% MULTI_STATS3D this function interpolates the 3D solution at each level to the finest
% level  equired to easily visualize and evalutate mean and var.
% UUU = multi_stats3D(U,P,nc,indset,noarv)
% input
%      U           : SFGEM Solution
%      nc          : FEM levels for each multi-index
%      indset      : index set
%      noarv       : number of active parameters
%
% outpt
%      UUU         :  SGFEM solution
%
% Multilevel SGFEM function: GP; 22 March 2022.
% Copyright (c) 2022 G. Papanikos, A.J. Crowder, C.E. Powell

global TP dom_type
fprintf('\nComputing statistics ... ')

nc_max = max(nc);

n_x_steps_max = 2^(nc_max) + 1;

if TP == 1 || TP ==5 || TP ==6
    x_steps_max = linspace(-1,1,n_x_steps_max);
    x_mean = 0;
    y_mean = 0;
    z_mean = 0;
end
if TP == 2 || TP == 3 || TP == 4
    x_steps_max = linspace(0,1,n_x_steps_max);
    x_mean = 1/2;
    y_mean = 1/2;
    z_mean = 1/2;
end

y_steps_max = x_steps_max;
z_steps_max = x_steps_max;

[~,~,xyz_max,bound_max] = grid_data3D(nc_max);
[X_max,Y_max,Z_max] = meshgrid(x_steps_max,y_steps_max,z_steps_max);

UUU = cell(1,P);

u = cell2mat(U);
U_gal = u_gal_reconstruct(u,nc); % add zeros to solution from boundary nodes and split into P pieces

for p = 1:P
    
    if nc(p) < nc_max
        
        [~,~,xyz,~] = grid_data3D(nc(p));
        
        n_x_steps = 2^(nc(p)) + 1;
        
        if TP == 1 || TP == 5 || TP == 6
            x_steps = linspace(-1,1,n_x_steps);
        end
        if TP == 2 || TP == 3 || TP == 4
            x_steps = linspace(0,1,n_x_steps);
        end
        
        y_steps = x_steps;
        z_steps = x_steps;
        
        [X,Y,Z] = meshgrid(x_steps,y_steps,z_steps);
        
        sol_len = size(xyz,1);
        if isequal(dom_type,'cube')
            UU = reshape(U_gal{p},nthroot(sol_len,3),nthroot(sol_len,3),nthroot(sol_len,3));
            UUU{p} = interp3(X,Y,Z,UU,X_max,Y_max,Z_max);
        else
            e_xysol = griddata(xyz(:,1),xyz(:,2),xyz(:,3),U_gal{p},X,Y,Z);
            for i=1:size(e_xysol,3)
                [II,JJ] = find(X(:,:,i)<0 & Z(:,:,i)<0);
                e_xysol(II,JJ,i) =nan;
            end
            UUU{p} = e_xysol;
        end
        
    else
        
        sol_len = size(xyz_max,1);
        
        non_bound = setdiff(1:sol_len,bound_max);
        
        UU = zeros(sol_len,1);
        UU(non_bound) = U{p};
        
        if isequal(dom_type,'cube')
            UUU{p} = reshape(UU,nthroot(sol_len,3),nthroot(sol_len,3),nthroot(sol_len,3));
        else
            e_xysol = griddata(xyz_max(:,1),xyz_max(:,2),xyz_max(:,3),UU,X_max,Y_max,Z_max);
            for i=1:size(e_xysol,3)
                [II,JJ] = find(X(:,:,i)<0 & Z(:,:,i)<0);
                e_xysol(II,JJ,i) =nan;
            end
            UUU{p} = e_xysol;
        end
        
    end
end


E = UUU{1}; V = UUU{2}.^2; % store mean and initialise variance

if P > 2
    for i = 3:P
        V = V + UUU{i}.^2;
    end
end

var = V;

max_mean = max(max(E(:)));
max_var = max(max(var(:))); cprintf('-text','completed\n');

str_max_mean = ['Max expectation = ',num2str(max_mean,'%5.4e'),'.'];
str_max_var  = ['Max variance = ',num2str(max_var,'%5.4e'),'.'];

disp(['  ',str_max_mean]) % display in command window
disp(['     ',str_max_var])


figure(250)
subplot(221),contourf(X_max(:,:,round(size(X_max,3)/2)),Y_max(:,:,round(size(Y_max,3)/2)),E(:,:,round(size(Z_max,3)/2)),12),axis('square')
xlabel('x_1') % x-axis label
ylabel('x_2') % y-axis label
colorbar
axis square
stre = ['\bf\fontsize{10} Cross section of the Expectation in x_3 = ', num2str(z_mean),' direction.'];
title({stre,str_max_mean,''},'FontWeight','Normal','FontSize',8)
colorbar;

subplot(222),
colorbar
daspect([1 1 1]);
axis([min(x_steps_max(:)) 1 min(y_steps_max(:)) 1 min(z_steps_max(:)) 1])
xlabel('x_1') % x-axis label
ylabel('x_2') % y-axis label
zlabel('x_3') % z-axis label

hold on
hSlice = slice(x_steps_max,y_steps_max,z_steps_max,E,mean(x_steps_max(:)),mean(y_steps_max(:)),mean(z_steps_max(:)));
set(hSlice,'EdgeColor','none','FaceColor','interp');

% adjust lighting
camlight;
camlight(-90,0);
lighting gouraud
colormap jet; 
view(330,30)
 
%%   

if TP == 2 || TP == 3 
 V =  permute(V,[1 3 2]);
end
subplot(223),contourf(X_max(:,:,round(size(X_max,3)/2)),Y_max(:,:,round(size(Y_max,3)/2)),V(:,:,round(size(Z_max,3)/2)),12),axis('square')
xlabel('x_1')
ylabel('x_2')
axis square
strv = ['\bf\fontsize{10} Cross section of the Variance in x_3 = ',num2str(z_mean),' direction.'];
title({strv,str_max_var,''},'FontWeight','Normal','FontSize',8)
colorbar;
subplot(224),

colorbar
daspect([1 1 1]);
axis([min(x_steps_max(:)) 1 min(y_steps_max(:)) 1 min(z_steps_max(:)) 1])
xlabel('x_1') % x-axis label
ylabel('x_2') % y-axis label
zlabel('x_3') % z-axis label

hold on
hSlice = slice(x_steps_max,y_steps_max,z_steps_max,V,mean(x_steps_max(:)),mean(y_steps_max(:)),mean(z_steps_max(:)));
set(hSlice,'EdgeColor','none','FaceColor','interp');


hold on
hSlice = slice(x_steps_max,y_steps_max,z_steps_max,V,5*mean(x_steps_max(:))/3,5*mean(y_steps_max(:))/3,mean(z_steps_max(:)));
set(hSlice,'EdgeColor','none','FaceColor','interp');

camlight;
camlight(-90,0);
lighting gouraud
colormap jet; 
view(330,30)


for p = 1:P
    UUU{p} = reshape(UUU{p},[],1);
end
UUU = cell2mat(UUU);

end

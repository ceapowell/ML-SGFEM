function f = stoch_specific_rhs(x,y,nel,norv)
%STOCH_SPECIFIC_RHS   deterministic nonconstant RHS forcing function 
%   f = stoch_specific_rhs(x,y,nel,norv)
%   input
%          x          x coordinate vector
%          y          y coordinate vector
%          nel        number of elements
%          norv       number of random variables
%
% SIFISS function: DJS; 2 May 2013.
% Copyright (c) 2013 A. Bespalov, C.E. Powell, D.J. Silvester

  f0 = (2*ones(nel,1) - x.^2 - y.^2)/8.0e0;
%%  f0 = ones(nel,1) ./ (x.^2 + y.^2).^(2/5);   singular rhs
  f=[f0,zeros(nel,norv)];

return
